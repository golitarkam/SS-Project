# New Power Coin

![](http://npw.live/images/logo-white2x.png)

## Introduction

A new masternode-enabled cryptocurrency that drives online traffic into a new era of decentralization.

New Power Coin will serve as the underlying foundation of the blockchain to provide a new source of traffic for the Internet. By using blockchain technology, internet traffic targeting will never be more accurate, and your data will never be owned by anyone.

**For more information, please visit: [New Power Coin Website](http://npw.live)**

**Visit our ANN thread at [Bitcointalk](https://bitcointalk.org/index.php?topic=3905211.0)**

## Coin Specs

### Total Supply

73,000,000 (~4 years)

### Masternode Collateral

20,000

### Block

Block Time: 2 Minutes

Block Size: 2 Megabytes

### Algorithm

NeoScrypt

### Block Rewards

| **PoW Phase Period**        | **PoS Phase Period**  |
| --------   | -----  |
| Masternodes: 70%, Miners: 30%      | Masternodes: 80%, PoS: 20%   |
| [block# 1] 7,000,000  (Premined)     |[block# 23601-300000] 100   |
| [block# 2-2000] 1    |[block# 300001-1000000] 50|
| [block# 2001-23600] 100 |[block# 1000001-2000000] 25 |
| |[block# 2000001-3000000] 12.5 |
| |[block# 3000001-] 6.25|


**Super blocks:**

15 super blocks for every 21600 blocks (~1 month), reward: 1000

### Premined

+ Development: 1,000,000
+ Public: 3,500,000
+ Airdrop Bounty & Reservation: 750,000
+ Angel investors: 1,750,000

### Ports

+ rpc port= 61473
+ p2p port= 61472
+ Testnet rpc port= 61475
+ Testnet p2p port = 61474

