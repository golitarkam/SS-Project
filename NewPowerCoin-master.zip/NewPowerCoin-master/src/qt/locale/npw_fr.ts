<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="fr_FR">
<context>
    <name>AddressBookPage</name>
    <message>
        <location filename="../forms/addressbookpage.ui" line="67"/>
        <source>Right-click to edit address or label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/addressbookpage.ui" line="94"/>
        <source>Create a new address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/addressbookpage.ui" line="97"/>
        <source>&amp;New</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/addressbookpage.ui" line="111"/>
        <source>Copy the currently selected address to the system clipboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/addressbookpage.ui" line="114"/>
        <source>&amp;Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/addressbookpage.ui" line="128"/>
        <source>Delete the currently selected address from the list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/addressbookpage.ui" line="131"/>
        <source>&amp;Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/addressbookpage.ui" line="158"/>
        <source>Export the data in the current tab to a file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/addressbookpage.ui" line="161"/>
        <source>&amp;Export</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/addressbookpage.ui" line="181"/>
        <source>C&amp;lose</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../addressbookpage.cpp" line="44"/>
        <source>Choose the address to send coins to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../addressbookpage.cpp" line="47"/>
        <source>Choose the address to receive coins with</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../addressbookpage.cpp" line="53"/>
        <source>C&amp;hoose</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../addressbookpage.cpp" line="59"/>
        <source>Sending addresses</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../addressbookpage.cpp" line="62"/>
        <source>Receiving addresses</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../addressbookpage.cpp" line="69"/>
        <source>These are your NPW addresses for sending payments. Always check the amount and the receiving address before sending coins.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../addressbookpage.cpp" line="73"/>
        <source>These are your NPW addresses for receiving payments. It is recommended to use a new receiving address for each transaction.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../addressbookpage.cpp" line="79"/>
        <source>&amp;Copy Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../addressbookpage.cpp" line="80"/>
        <source>Copy &amp;Label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../addressbookpage.cpp" line="81"/>
        <source>&amp;Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../addressbookpage.cpp" line="268"/>
        <source>Export Address List</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../addressbookpage.cpp" line="269"/>
        <source>Comma separated file (*.csv)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../addressbookpage.cpp" line="282"/>
        <source>Exporting Failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../addressbookpage.cpp" line="283"/>
        <source>There was an error trying to save the address list to %1. Please try again.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AddressTableModel</name>
    <message>
        <location filename="../addresstablemodel.cpp" line="199"/>
        <source>Label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../addresstablemodel.cpp" line="199"/>
        <source>Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../addresstablemodel.cpp" line="232"/>
        <source>(no label)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AskPassphraseDialog</name>
    <message>
        <location filename="../forms/askpassphrasedialog.ui" line="26"/>
        <source>Passphrase Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/askpassphrasedialog.ui" line="56"/>
        <source>Enter passphrase</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/askpassphrasedialog.ui" line="70"/>
        <source>New passphrase</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/askpassphrasedialog.ui" line="84"/>
        <source>Repeat new passphrase</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/askpassphrasedialog.ui" line="117"/>
        <source>Serves to disable the trivial sendmoney when OS account compromised. Provides no real security.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/askpassphrasedialog.ui" line="120"/>
        <source>For anonymization, automint, and staking only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="48"/>
        <source>Enter the new passphrase to the wallet.&lt;br/&gt;Please use a passphrase of &lt;b&gt;ten or more random characters&lt;/b&gt;, or &lt;b&gt;eight or more words&lt;/b&gt;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="51"/>
        <source>Encrypt wallet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="56"/>
        <source>This operation needs your wallet passphrase to unlock the wallet.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="61"/>
        <source>Unlock wallet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="64"/>
        <source>This operation needs your wallet passphrase to decrypt the wallet.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="69"/>
        <source>Decrypt wallet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="72"/>
        <source>Change passphrase</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="73"/>
        <source>Enter the old and new passphrase to the wallet.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="125"/>
        <source>Confirm wallet encryption</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="126"/>
        <source>Warning: If you encrypt your wallet and lose your passphrase, you will &lt;b&gt;LOSE ALL OF YOUR NPW&lt;/b&gt;!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="126"/>
        <source>Are you sure you wish to encrypt your wallet?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="132"/>
        <location filename="../askpassphrasedialog.cpp" line="177"/>
        <source>Wallet encrypted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="134"/>
        <source>NPW will close now to finish the encryption process. Remember that encrypting your wallet cannot fully protect your NPWs from being stolen by malware infecting your computer.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="138"/>
        <source>IMPORTANT: Any previous backups you have made of your wallet file should be replaced with the newly generated, encrypted wallet file. For security reasons, previous backups of the unencrypted wallet file will become useless as soon as you start using the new, encrypted wallet.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="145"/>
        <location filename="../askpassphrasedialog.cpp" line="150"/>
        <location filename="../askpassphrasedialog.cpp" line="181"/>
        <location filename="../askpassphrasedialog.cpp" line="185"/>
        <source>Wallet encryption failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="146"/>
        <source>Wallet encryption failed due to an internal error. Your wallet was not encrypted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="151"/>
        <location filename="../askpassphrasedialog.cpp" line="186"/>
        <source>The supplied passphrases do not match.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="160"/>
        <source>Wallet unlock failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="161"/>
        <location filename="../askpassphrasedialog.cpp" line="169"/>
        <location filename="../askpassphrasedialog.cpp" line="182"/>
        <source>The passphrase entered for the wallet decryption was incorrect.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="168"/>
        <source>Wallet decryption failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="178"/>
        <source>Wallet passphrase was successfully changed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="221"/>
        <location filename="../askpassphrasedialog.cpp" line="245"/>
        <source>Warning: The Caps Lock key is on!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BitcoinGUI</name>
    <message>
        <location filename="../bitcoingui.cpp" line="120"/>
        <location filename="../bitcoingui.cpp" line="1046"/>
        <source>NPW Core</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="128"/>
        <source>Wallet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="130"/>
        <source>Node</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="308"/>
        <source>&amp;Overview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="309"/>
        <source>Show general overview of wallet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="319"/>
        <source>&amp;Send</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="320"/>
        <source>Send coins to a NPW address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="330"/>
        <source>&amp;Receive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="331"/>
        <source>Request payments (generates QR codes and NPW: URIs)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="341"/>
        <source>&amp;Transactions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="342"/>
        <source>Browse transaction history</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="352"/>
        <source>&amp;Privacy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="353"/>
        <source>Privacy Actions for zNPW</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="367"/>
        <source>&amp;Masternodes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="368"/>
        <source>Browse masternodes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="395"/>
        <source>E&amp;xit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="396"/>
        <source>Quit application</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="399"/>
        <source>&amp;About NPW Core</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="400"/>
        <source>Show information about NPW Core</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="403"/>
        <location filename="../bitcoingui.cpp" line="405"/>
        <source>About &amp;Qt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="407"/>
        <source>Show information about Qt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="409"/>
        <source>&amp;Options...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="410"/>
        <source>Modify configuration options for NPW</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="412"/>
        <source>&amp;Show / Hide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="413"/>
        <source>Show or hide the main Window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="415"/>
        <source>&amp;Encrypt Wallet...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="416"/>
        <source>Encrypt the private keys that belong to your wallet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="418"/>
        <source>&amp;Backup Wallet...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="419"/>
        <source>Backup wallet to another location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="420"/>
        <source>&amp;Change Passphrase...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="421"/>
        <source>Change the passphrase used for wallet encryption</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="422"/>
        <source>&amp;Unlock Wallet...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="423"/>
        <source>Unlock wallet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="424"/>
        <source>&amp;Lock Wallet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="425"/>
        <source>Sign &amp;message...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="426"/>
        <source>Sign messages with your NPW addresses to prove you own them</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="427"/>
        <source>&amp;Verify message...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="428"/>
        <source>Verify messages to ensure they were signed with specified NPW addresses</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="429"/>
        <source>&amp;BIP38 tool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="430"/>
        <source>Encrypt and decrypt private keys using a passphrase</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="431"/>
        <source>&amp;MultiSend</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="432"/>
        <source>MultiSend Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="435"/>
        <source>&amp;Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="436"/>
        <source>Show diagnostic information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="437"/>
        <source>&amp;Debug console</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="438"/>
        <source>Open debugging console</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="439"/>
        <source>&amp;Network Monitor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="440"/>
        <source>Show network monitor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="441"/>
        <source>&amp;Peers list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="442"/>
        <source>Show peers info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="443"/>
        <source>Wallet &amp;Repair</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="444"/>
        <source>Show wallet repair options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="445"/>
        <source>Open Wallet &amp;Configuration File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="446"/>
        <source>Open configuration file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="447"/>
        <source>Open &amp;Masternode Configuration File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="448"/>
        <source>Open Masternode configuration file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="449"/>
        <source>Show Automatic &amp;Backups</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="450"/>
        <source>Show automatically created wallet backups</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="452"/>
        <source>&amp;Sending addresses...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="453"/>
        <source>Show the list of used sending addresses and labels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="454"/>
        <source>&amp;Receiving addresses...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="455"/>
        <source>Show the list of used receiving addresses and labels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="457"/>
        <source>&amp;Multisignature creation...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="458"/>
        <source>Create a new multisignature address and add it to this wallet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="459"/>
        <source>&amp;Multisignature spending...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="460"/>
        <source>Spend from a multisignature address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="461"/>
        <source>&amp;Multisignature signing...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="462"/>
        <source>Sign with a multisignature address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="464"/>
        <source>Open &amp;URI...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="465"/>
        <source>Open a NPW: URI or payment request</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="466"/>
        <source>&amp;Blockchain explorer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="467"/>
        <source>Block explorer window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="469"/>
        <source>&amp;Command-line options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="471"/>
        <source>Show the NPW Core help message to get a list with possible NPW command-line options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="511"/>
        <source>&amp;File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="528"/>
        <source>&amp;Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="541"/>
        <source>&amp;Tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="554"/>
        <source>&amp;Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="564"/>
        <source>Tabs toolbar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="704"/>
        <source>NPW Core client</source>
        <translation type="unfinished"></translation>
    </message>
    <message numerus="yes">
        <location filename="../bitcoingui.cpp" line="916"/>
        <source>%n active connection(s) to NPW network</source>
        <translation type="unfinished">
            <numerusform></numerusform>
            <numerusform></numerusform>
        </translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="931"/>
        <source>Synchronizing with network...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="934"/>
        <source>Importing blocks from disk...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="937"/>
        <source>Reindexing blocks on disk...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="941"/>
        <source>No block source available...</source>
        <translation type="unfinished"></translation>
    </message>
    <message numerus="yes">
        <location filename="../bitcoingui.cpp" line="951"/>
        <source>Processed %n blocks of transaction history.</source>
        <translation type="unfinished">
            <numerusform></numerusform>
            <numerusform></numerusform>
        </translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="957"/>
        <source>Up to date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="983"/>
        <source>Synchronizing additional data: %p%</source>
        <translation type="unfinished"></translation>
    </message>
    <message numerus="yes">
        <location filename="../bitcoingui.cpp" line="998"/>
        <source>%n hour(s)</source>
        <translation type="unfinished">
            <numerusform></numerusform>
            <numerusform></numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location filename="../bitcoingui.cpp" line="1000"/>
        <source>%n day(s)</source>
        <translation type="unfinished">
            <numerusform></numerusform>
            <numerusform></numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location filename="../bitcoingui.cpp" line="1002"/>
        <location filename="../bitcoingui.cpp" line="1006"/>
        <source>%n week(s)</source>
        <translation type="unfinished">
            <numerusform></numerusform>
            <numerusform></numerusform>
        </translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="1006"/>
        <source>%1 and %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message numerus="yes">
        <location filename="../bitcoingui.cpp" line="1006"/>
        <source>%n year(s)</source>
        <translation type="unfinished">
            <numerusform></numerusform>
            <numerusform></numerusform>
        </translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="1010"/>
        <source>%1 behind. Scanning block %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="1015"/>
        <source>Catching up...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="1031"/>
        <source>Last received block was generated %1 ago.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="1033"/>
        <source>Transactions after this will not yet be visible.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="1059"/>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="1062"/>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="1065"/>
        <source>Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="1134"/>
        <source>Sent MultiSend transaction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="1134"/>
        <source>Sent transaction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="1134"/>
        <source>Incoming transaction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="1135"/>
        <source>Date: %1
Amount: %2
Type: %3
Address: %4
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="1187"/>
        <source>Staking is active
 MultiSend: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="1187"/>
        <location filename="../bitcoingui.cpp" line="1191"/>
        <source>Active</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="1187"/>
        <location filename="../bitcoingui.cpp" line="1191"/>
        <source>Not Active</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="1191"/>
        <source>Staking is not active
 MultiSend: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="1200"/>
        <source>AutoMint is currently enabled and set to </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="1204"/>
        <source>AutoMint is disabled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="1233"/>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;unlocked&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="1243"/>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;unlocked&lt;/b&gt; for anonymization and staking only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="1253"/>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;locked&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npw.cpp" line="504"/>
        <source>A fatal error occurred. NPW can no longer continue safely and will quit.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ClientModel</name>
    <message>
        <location filename="../clientmodel.cpp" line="80"/>
        <source>Total: %1 (IPv4: %2 / IPv6: %3 / Tor: %4 / Unknown: %5)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clientmodel.cpp" line="181"/>
        <source>Network Alert</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CoinControlDialog</name>
    <message>
        <location filename="../forms/coincontroldialog.ui" line="14"/>
        <source>Coin Selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/coincontroldialog.ui" line="48"/>
        <source>Quantity:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/coincontroldialog.ui" line="77"/>
        <source>Bytes:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/coincontroldialog.ui" line="122"/>
        <source>Amount:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/coincontroldialog.ui" line="151"/>
        <source>Priority:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/coincontroldialog.ui" line="164"/>
        <location filename="../coincontroldialog.cpp" line="477"/>
        <source>medium</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/coincontroldialog.ui" line="196"/>
        <source>Fee:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/coincontroldialog.ui" line="228"/>
        <source>Dust:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/coincontroldialog.ui" line="244"/>
        <location filename="../coincontroldialog.cpp" line="682"/>
        <source>no</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/coincontroldialog.ui" line="276"/>
        <source>After Fee:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/coincontroldialog.ui" line="308"/>
        <source>Change:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/coincontroldialog.ui" line="364"/>
        <source>(un)select all</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/coincontroldialog.ui" line="380"/>
        <source>toggle lock state</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/coincontroldialog.ui" line="396"/>
        <source>Tree mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/coincontroldialog.ui" line="409"/>
        <source>List mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/coincontroldialog.ui" line="419"/>
        <source>(1 locked)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/coincontroldialog.ui" line="465"/>
        <source>Amount</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/coincontroldialog.ui" line="470"/>
        <source>Received with label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/coincontroldialog.ui" line="475"/>
        <source>Received with address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/coincontroldialog.ui" line="480"/>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/coincontroldialog.ui" line="485"/>
        <source>Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/coincontroldialog.ui" line="490"/>
        <source>Confirmations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/coincontroldialog.ui" line="493"/>
        <source>Confirmed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/coincontroldialog.ui" line="498"/>
        <source>Priority</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../coincontroldialog.cpp" line="52"/>
        <source>Copy address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../coincontroldialog.cpp" line="53"/>
        <source>Copy label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../coincontroldialog.cpp" line="54"/>
        <location filename="../coincontroldialog.cpp" line="80"/>
        <source>Copy amount</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../coincontroldialog.cpp" line="55"/>
        <source>Copy transaction ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../coincontroldialog.cpp" line="56"/>
        <source>Lock unspent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../coincontroldialog.cpp" line="57"/>
        <source>Unlock unspent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../coincontroldialog.cpp" line="79"/>
        <source>Copy quantity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../coincontroldialog.cpp" line="81"/>
        <source>Copy fee</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../coincontroldialog.cpp" line="82"/>
        <source>Copy after fee</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../coincontroldialog.cpp" line="83"/>
        <source>Copy bytes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../coincontroldialog.cpp" line="84"/>
        <source>Copy priority</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../coincontroldialog.cpp" line="85"/>
        <source>Copy dust</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../coincontroldialog.cpp" line="86"/>
        <source>Copy change</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../coincontroldialog.cpp" line="249"/>
        <source>Please switch to &quot;List mode&quot; to use this function.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../coincontroldialog.cpp" line="469"/>
        <source>highest</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../coincontroldialog.cpp" line="471"/>
        <source>higher</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../coincontroldialog.cpp" line="473"/>
        <source>high</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../coincontroldialog.cpp" line="475"/>
        <source>medium-high</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../coincontroldialog.cpp" line="479"/>
        <source>low-medium</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../coincontroldialog.cpp" line="481"/>
        <source>low</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../coincontroldialog.cpp" line="483"/>
        <source>lower</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../coincontroldialog.cpp" line="485"/>
        <source>lowest</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../coincontroldialog.cpp" line="494"/>
        <source>(%1 locked)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../coincontroldialog.cpp" line="556"/>
        <source>none</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../coincontroldialog.cpp" line="682"/>
        <source>yes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../coincontroldialog.cpp" line="697"/>
        <source>This label turns red, if the transaction size is greater than 1000 bytes.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../coincontroldialog.cpp" line="698"/>
        <location filename="../coincontroldialog.cpp" line="703"/>
        <source>This means a fee of at least %1 per kB is required.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../coincontroldialog.cpp" line="699"/>
        <source>Can vary +/- 1 byte per input.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../coincontroldialog.cpp" line="701"/>
        <source>Transactions with higher priority are more likely to get included into a block.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../coincontroldialog.cpp" line="702"/>
        <source>This label turns red, if the priority is smaller than &quot;medium&quot;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../coincontroldialog.cpp" line="705"/>
        <source>This label turns red, if any recipient receives an amount smaller than %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../coincontroldialog.cpp" line="713"/>
        <source>Can vary +/- %1 unpw per input.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../coincontroldialog.cpp" line="759"/>
        <location filename="../coincontroldialog.cpp" line="840"/>
        <source>(no label)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../coincontroldialog.cpp" line="835"/>
        <source>change from %1 (%2)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../coincontroldialog.cpp" line="836"/>
        <source>(change)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EditAddressDialog</name>
    <message>
        <location filename="../forms/editaddressdialog.ui" line="14"/>
        <source>Edit Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/editaddressdialog.ui" line="25"/>
        <source>&amp;Label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/editaddressdialog.ui" line="35"/>
        <source>The label associated with this address list entry</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/editaddressdialog.ui" line="42"/>
        <source>&amp;Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/editaddressdialog.ui" line="52"/>
        <source>The address associated with this address list entry. This can only be modified for sending addresses.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../editaddressdialog.cpp" line="28"/>
        <source>New receiving address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../editaddressdialog.cpp" line="32"/>
        <source>New sending address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../editaddressdialog.cpp" line="35"/>
        <source>Edit receiving address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../editaddressdialog.cpp" line="39"/>
        <source>Edit sending address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../editaddressdialog.cpp" line="106"/>
        <source>The entered address &quot;%1&quot; is not a valid NPW address.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../editaddressdialog.cpp" line="111"/>
        <source>The entered address &quot;%1&quot; is already in the address book.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../editaddressdialog.cpp" line="116"/>
        <source>Could not unlock wallet.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../editaddressdialog.cpp" line="121"/>
        <source>New key generation failed.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FreespaceChecker</name>
    <message>
        <location filename="../intro.cpp" line="70"/>
        <source>A new data directory will be created.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../intro.cpp" line="89"/>
        <source>name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../intro.cpp" line="91"/>
        <source>Directory already exists. Add %1 if you intend to create a new directory here.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../intro.cpp" line="94"/>
        <source>Path already exists, and is not a directory.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../intro.cpp" line="100"/>
        <source>Cannot create data directory here.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HelpMessageDialog</name>
    <message>
        <location filename="../utilitydialog.cpp" line="37"/>
        <source>NPW Core</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../utilitydialog.cpp" line="37"/>
        <source>version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../utilitydialog.cpp" line="42"/>
        <location filename="../utilitydialog.cpp" line="44"/>
        <source>(%1-bit)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../utilitydialog.cpp" line="48"/>
        <source>About NPW Core</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../utilitydialog.cpp" line="68"/>
        <source>Command-line options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../utilitydialog.cpp" line="69"/>
        <source>Usage:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../utilitydialog.cpp" line="70"/>
        <source>command-line options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../utilitydialog.cpp" line="78"/>
        <source>UI Options:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../utilitydialog.cpp" line="79"/>
        <source>Choose data directory on startup (default: %u)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../utilitydialog.cpp" line="80"/>
        <source>Set language, for example &quot;de_DE&quot; (default: system locale)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../utilitydialog.cpp" line="81"/>
        <source>Start minimized</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../utilitydialog.cpp" line="82"/>
        <source>Set SSL root certificates for payment request (default: -system-)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../utilitydialog.cpp" line="83"/>
        <source>Show splash screen on startup (default: %u)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Intro</name>
    <message>
        <location filename="../forms/intro.ui" line="14"/>
        <source>Welcome</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/intro.ui" line="23"/>
        <source>Welcome to NPW Core.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/intro.ui" line="49"/>
        <source>As this is the first time the program is launched, you can choose where NPW Core will store its data.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/intro.ui" line="59"/>
        <source>NPW Core will download and store a copy of the NPW block chain. At least %1GB of data will be stored in this directory, and it will grow over time. The wallet will also be stored in this directory.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/intro.ui" line="69"/>
        <source>Use the default data directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/intro.ui" line="76"/>
        <source>Use a custom data directory:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../intro.cpp" line="177"/>
        <source>NPW Core</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../intro.cpp" line="178"/>
        <source>Error: Specified data directory &quot;%1&quot; cannot be created.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../intro.cpp" line="202"/>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../intro.cpp" line="210"/>
        <source>%1 GB of free space available</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../intro.cpp" line="212"/>
        <source>(of %1 GB needed)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ObfuscationConfig</name>
    <message>
        <location filename="../forms/obfuscationconfig.ui" line="14"/>
        <source>Configure Obfuscation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/obfuscationconfig.ui" line="26"/>
        <source>Basic Privacy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/obfuscationconfig.ui" line="39"/>
        <source>High Privacy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/obfuscationconfig.ui" line="52"/>
        <source>Maximum Privacy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/obfuscationconfig.ui" line="65"/>
        <source>Please select a privacy level.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/obfuscationconfig.ui" line="78"/>
        <source>Use 2 separate masternodes to mix funds up to 10000 NPW</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/obfuscationconfig.ui" line="91"/>
        <source>Use 8 separate masternodes to mix funds up to 10000 NPW</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/obfuscationconfig.ui" line="104"/>
        <source>Use 16 separate masternodes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/obfuscationconfig.ui" line="117"/>
        <source>This option is the quickest and will cost about ~0.025 NPW to anonymize 10000 NPW</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/obfuscationconfig.ui" line="130"/>
        <source>This option is moderately fast and will cost about 0.05 NPW to anonymize 10000 NPW</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/obfuscationconfig.ui" line="143"/>
        <source>This is the slowest and most secure option. Using maximum anonymity will cost</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/obfuscationconfig.ui" line="156"/>
        <source>0.1 NPW per 10000 NPW you anonymize.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../obfuscationconfig.cpp" line="42"/>
        <location filename="../obfuscationconfig.cpp" line="56"/>
        <location filename="../obfuscationconfig.cpp" line="70"/>
        <source>Obfuscation Configuration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../obfuscationconfig.cpp" line="43"/>
        <source>Obfuscation was successfully set to basic (%1 and 2 rounds). You can change this at any time by opening NPW&apos;s configuration screen.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../obfuscationconfig.cpp" line="57"/>
        <source>Obfuscation was successfully set to high (%1 and 8 rounds). You can change this at any time by opening NPW&apos;s configuration screen.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../obfuscationconfig.cpp" line="71"/>
        <source>Obfuscation was successfully set to maximum (%1 and 16 rounds). You can change this at any time by opening NPW&apos;s configuration screen.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>OpenURIDialog</name>
    <message>
        <location filename="../forms/openuridialog.ui" line="14"/>
        <source>Open URI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/openuridialog.ui" line="20"/>
        <source>Open payment request from URI or file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/openuridialog.ui" line="29"/>
        <source>URI:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/openuridialog.ui" line="39"/>
        <source>Select payment request file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../openuridialog.cpp" line="47"/>
        <source>Select payment request file to open</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>OptionsDialog</name>
    <message>
        <location filename="../forms/optionsdialog.ui" line="14"/>
        <source>Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/optionsdialog.ui" line="27"/>
        <source>&amp;Main</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/optionsdialog.ui" line="33"/>
        <source>Automatically start NPW after logging in to the system.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/optionsdialog.ui" line="36"/>
        <source>&amp;Start NPW on system login</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/optionsdialog.ui" line="45"/>
        <source>Size of &amp;database cache</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/optionsdialog.ui" line="61"/>
        <source>MB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/optionsdialog.ui" line="88"/>
        <source>Number of script &amp;verification threads</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/optionsdialog.ui" line="101"/>
        <source>(0 = auto, &lt;0 = leave that many cores free)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/optionsdialog.ui" line="136"/>
        <source>Enable automatic minting of NPW units to zNPW</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/optionsdialog.ui" line="142"/>
        <source>Enable zNPW Automint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/optionsdialog.ui" line="151"/>
        <source>Percentage of incoming NPW which get automatically converted to zNPW via Zerocoin Protocol (min: 10%)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/optionsdialog.ui" line="154"/>
        <source>Percentage of autominted zNPW</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/optionsdialog.ui" line="184"/>
        <location filename="../forms/optionsdialog.ui" line="200"/>
        <source>Wait with automatic conversion to Zerocoin until enough NPW for this denomination is available</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/optionsdialog.ui" line="187"/>
        <source>Preferred Automint zNPW Denomination</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/optionsdialog.ui" line="216"/>
        <source>W&amp;allet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/optionsdialog.ui" line="224"/>
        <source>Stake split threshold:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/optionsdialog.ui" line="243"/>
        <source>Expert</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/optionsdialog.ui" line="249"/>
        <source>Whether to show coin control features or not.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/optionsdialog.ui" line="252"/>
        <source>Enable coin &amp;control features</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/optionsdialog.ui" line="259"/>
        <source>Show additional tab listing all your masternodes in first sub-tab&lt;br/&gt;and all masternodes on the network in second sub-tab.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/optionsdialog.ui" line="262"/>
        <source>Show Masternodes Tab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/optionsdialog.ui" line="269"/>
        <source>If you disable the spending of unconfirmed change, the change from a transaction&lt;br/&gt;cannot be used until that transaction has at least one confirmation.&lt;br/&gt;This also affects how your balance is computed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/optionsdialog.ui" line="272"/>
        <source>&amp;Spend unconfirmed change</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/optionsdialog.ui" line="296"/>
        <source>&amp;Network</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/optionsdialog.ui" line="302"/>
        <source>Automatically open the NPW client port on the router. This only works when your router supports UPnP and it is enabled.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/optionsdialog.ui" line="305"/>
        <source>Map port using &amp;UPnP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/optionsdialog.ui" line="312"/>
        <source>Accept connections from outside</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/optionsdialog.ui" line="315"/>
        <source>Allow incoming connections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/optionsdialog.ui" line="322"/>
        <source>Connect to the NPW network through a SOCKS5 proxy.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/optionsdialog.ui" line="325"/>
        <source>&amp;Connect through SOCKS5 proxy (default proxy):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/optionsdialog.ui" line="334"/>
        <source>Proxy &amp;IP:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/optionsdialog.ui" line="359"/>
        <source>IP address of the proxy (e.g. IPv4: 127.0.0.1 / IPv6: ::1)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/optionsdialog.ui" line="366"/>
        <source>&amp;Port:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/optionsdialog.ui" line="391"/>
        <source>Port of the proxy (e.g. 9050)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/optionsdialog.ui" line="427"/>
        <source>&amp;Window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/optionsdialog.ui" line="433"/>
        <source>Show only a tray icon after minimizing the window.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/optionsdialog.ui" line="436"/>
        <source>&amp;Minimize to the tray instead of the taskbar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/optionsdialog.ui" line="443"/>
        <source>Minimize instead of exit the application when the window is closed. When this option is enabled, the application will be closed only after selecting Quit in the menu.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/optionsdialog.ui" line="446"/>
        <source>M&amp;inimize on close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/optionsdialog.ui" line="467"/>
        <source>&amp;Display</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/optionsdialog.ui" line="475"/>
        <source>User Interface &amp;language:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/optionsdialog.ui" line="488"/>
        <source>The user interface language can be set here. This setting will take effect after restarting NPW.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/optionsdialog.ui" line="509"/>
        <source>Language missing or translation incomplete? Help contributing translations here:
https://www.transifex.com/npw-project/npw-project-translations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/optionsdialog.ui" line="528"/>
        <source>User Interface Theme:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/optionsdialog.ui" line="549"/>
        <source>&amp;Unit to show amounts in:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/optionsdialog.ui" line="562"/>
        <source>Choose the default subdivision unit to show in the interface and when sending coins.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/optionsdialog.ui" line="573"/>
        <source>Decimal digits</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/optionsdialog.ui" line="585"/>
        <location filename="../forms/optionsdialog.ui" line="591"/>
        <source>Hide empty balances</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/optionsdialog.ui" line="600"/>
        <location filename="../forms/optionsdialog.ui" line="613"/>
        <source>Third party URLs (e.g. a block explorer) that appear in the transactions tab as context menu items. %s in the URL is replaced by transaction hash. Multiple URLs are separated by vertical bar |.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/optionsdialog.ui" line="603"/>
        <source>Third party transaction URLs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/optionsdialog.ui" line="644"/>
        <source>Active command-line options that override above options:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/optionsdialog.ui" line="687"/>
        <source>Reset all client options to default.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/optionsdialog.ui" line="690"/>
        <source>&amp;Reset Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/optionsdialog.ui" line="751"/>
        <source>&amp;OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/optionsdialog.ui" line="764"/>
        <source>&amp;Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="88"/>
        <source>Any</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="111"/>
        <source>default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="166"/>
        <source>none</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="258"/>
        <source>Confirm options reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="259"/>
        <location filename="../optionsdialog.cpp" line="289"/>
        <source>Client restart required to activate changes.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="259"/>
        <source>Client will be shutdown, do you want to proceed?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="291"/>
        <source>This change would require a client restart.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="313"/>
        <source>The supplied proxy address is invalid.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="320"/>
        <source>The supplied proxy port is invalid.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="328"/>
        <source>The supplied proxy settings are invalid.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>OverviewPage</name>
    <message>
        <location filename="../forms/overviewpage.ui" line="20"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/overviewpage.ui" line="115"/>
        <source>OVERVIEW</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/overviewpage.ui" line="249"/>
        <source>Combined Balance (including unconfirmed and immature coins)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/overviewpage.ui" line="252"/>
        <source>Combined Balance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/overviewpage.ui" line="262"/>
        <location filename="../forms/overviewpage.ui" line="1114"/>
        <source>The displayed information may be out of date. Your wallet automatically synchronizes with the NPW network after a connection is established, but this process has not completed yet.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/overviewpage.ui" line="317"/>
        <location filename="../forms/overviewpage.ui" line="509"/>
        <location filename="../forms/overviewpage.ui" line="912"/>
        <source>Available:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/overviewpage.ui" line="333"/>
        <location filename="../forms/overviewpage.ui" line="525"/>
        <source>Your current spendable balance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/overviewpage.ui" line="349"/>
        <location filename="../forms/overviewpage.ui" line="740"/>
        <location filename="../forms/overviewpage.ui" line="1004"/>
        <source>Total:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/overviewpage.ui" line="365"/>
        <source>Total Balance, including all unavailable coins.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/overviewpage.ui" line="436"/>
        <source>NPW Balance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/overviewpage.ui" line="489"/>
        <source>Spendable:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/overviewpage.ui" line="499"/>
        <source>Watch-only:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/overviewpage.ui" line="550"/>
        <source>Your current balance in watch-only addresses</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/overviewpage.ui" line="566"/>
        <source>Pending:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/overviewpage.ui" line="582"/>
        <source>Total of transactions that have yet to be confirmed, and do not yet count toward the spendable balance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/overviewpage.ui" line="607"/>
        <source>Unconfirmed transactions to watch-only addresses</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/overviewpage.ui" line="623"/>
        <location filename="../forms/overviewpage.ui" line="974"/>
        <source>Immature:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/overviewpage.ui" line="639"/>
        <source>Staked or masternode rewards that has not yet matured</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/overviewpage.ui" line="664"/>
        <source>Staked or masternode rewards in watch-only addresses that has not yet matured</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/overviewpage.ui" line="680"/>
        <location filename="../forms/overviewpage.ui" line="699"/>
        <source>Locked NPW or Masternode collaterals. These are excluded from zNPW minting.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/overviewpage.ui" line="683"/>
        <source>Locked:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/overviewpage.ui" line="724"/>
        <source>Current locked balance in watch-only addresses</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/overviewpage.ui" line="743"/>
        <location filename="../forms/overviewpage.ui" line="759"/>
        <source>Your current NPW balance, unconfirmed and immature transactions included</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/overviewpage.ui" line="784"/>
        <source>Current total balance in watch-only addresses</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/overviewpage.ui" line="855"/>
        <source>zNPW Balance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/overviewpage.ui" line="908"/>
        <location filename="../forms/overviewpage.ui" line="925"/>
        <source>Mature: more than 20 confirmation and more than 3 mints of the same denomination after it was minted.
These zNPW are spendable.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/overviewpage.ui" line="939"/>
        <location filename="../forms/overviewpage.ui" line="956"/>
        <location filename="../forms/overviewpage.ui" line="970"/>
        <location filename="../forms/overviewpage.ui" line="987"/>
        <source>Unconfirmed: less than 20 confirmations
Immature: confirmed, but less than 3 mints of the same denomination after it was minted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/overviewpage.ui" line="943"/>
        <source>Unconfirmed:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/overviewpage.ui" line="1001"/>
        <location filename="../forms/overviewpage.ui" line="1020"/>
        <source>Your current zNPW balance, unconfirmed and immature zNPW included.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/overviewpage.ui" line="1104"/>
        <source>Recent transactions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../overviewpage.cpp" line="149"/>
        <location filename="../overviewpage.cpp" line="150"/>
        <source>out of sync</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../overviewpage.cpp" line="255"/>
        <source>Current percentage of zNPW.
If AutoMint is enabled this percentage will settle around the configured AutoMint percentage (default = 10%).
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../overviewpage.cpp" line="259"/>
        <source>AutoMint is currently enabled and set to </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../overviewpage.cpp" line="260"/>
        <source>To disable AutoMint add &apos;enablezeromint=0&apos; in npw.conf.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../overviewpage.cpp" line="263"/>
        <source>AutoMint is currently disabled.
To enable AutoMint change &apos;enablezeromint=0&apos; to &apos;enablezeromint=1&apos; in npw.conf</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PaymentServer</name>
    <message>
        <location filename="../paymentserver.cpp" line="297"/>
        <location filename="../paymentserver.cpp" line="506"/>
        <location filename="../paymentserver.cpp" line="539"/>
        <location filename="../paymentserver.cpp" line="643"/>
        <location filename="../paymentserver.cpp" line="655"/>
        <location filename="../paymentserver.cpp" line="669"/>
        <source>Payment request error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../paymentserver.cpp" line="298"/>
        <source>Cannot start npw: click-to-pay handler</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../paymentserver.cpp" line="394"/>
        <location filename="../paymentserver.cpp" line="406"/>
        <location filename="../paymentserver.cpp" line="411"/>
        <source>URI handling</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../paymentserver.cpp" line="395"/>
        <source>Payment request fetch URL is invalid: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../paymentserver.cpp" line="406"/>
        <source>Invalid payment address %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../paymentserver.cpp" line="412"/>
        <source>URI cannot be parsed! This can be caused by an invalid NPW address or malformed URI parameters.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../paymentserver.cpp" line="424"/>
        <source>Payment request file handling</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../paymentserver.cpp" line="425"/>
        <source>Payment request file cannot be read! This can be caused by an invalid payment request file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../paymentserver.cpp" line="492"/>
        <location filename="../paymentserver.cpp" line="500"/>
        <location filename="../paymentserver.cpp" line="530"/>
        <source>Payment request rejected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../paymentserver.cpp" line="492"/>
        <source>Payment request network doesn&apos;t match client network.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../paymentserver.cpp" line="500"/>
        <source>Payment request has expired.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../paymentserver.cpp" line="506"/>
        <source>Payment request is not initialized.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../paymentserver.cpp" line="531"/>
        <source>Unverified payment requests to custom payment scripts are unsupported.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../paymentserver.cpp" line="539"/>
        <source>Requested payment amount of %1 is too small (considered dust).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../paymentserver.cpp" line="587"/>
        <source>Refund from %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../paymentserver.cpp" line="627"/>
        <source>Payment request %1 is too large (%2 bytes, allowed %3 bytes).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../paymentserver.cpp" line="633"/>
        <source>Payment request DoS protection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../paymentserver.cpp" line="638"/>
        <source>Error communicating with %1: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../paymentserver.cpp" line="656"/>
        <source>Payment request cannot be parsed!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../paymentserver.cpp" line="665"/>
        <source>Bad response from server %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../paymentserver.cpp" line="685"/>
        <source>Network request error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../paymentserver.cpp" line="696"/>
        <source>Payment acknowledged</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PeerTableModel</name>
    <message>
        <location filename="../peertablemodel.cpp" line="114"/>
        <source>Address/Hostname</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../peertablemodel.cpp" line="114"/>
        <source>Version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../peertablemodel.cpp" line="114"/>
        <source>Ping Time</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PrivacyDialog</name>
    <message>
        <location filename="../forms/privacydialog.ui" line="73"/>
        <source>PRIVACY</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="184"/>
        <source>Zerocoin Actions:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="194"/>
        <source>The displayed information may be out of date. Your wallet automatically synchronizes with the NPW network after a connection is established, but this process has not completed yet.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="255"/>
        <location filename="../forms/privacydialog.ui" line="307"/>
        <source>Enter an amount of NPW to convert to zNPW</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="258"/>
        <source>Mint Zerocoin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="271"/>
        <location filename="../forms/privacydialog.ui" line="622"/>
        <location filename="../forms/privacydialog.ui" line="652"/>
        <source>0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="281"/>
        <location filename="../forms/privacydialog.ui" line="935"/>
        <source>zNPW</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="288"/>
        <source>Available for minting are coins which are confirmed and not locked or Masternode collaterals.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="291"/>
        <source>Available for Minting:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="310"/>
        <source>0.000 000 00 NPW</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="339"/>
        <source>Reset Zerocoin Wallet DB. Deletes transactions that did not make it into the blockchain.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="342"/>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="368"/>
        <source>Coin Control...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="404"/>
        <source>Quantity:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="426"/>
        <source>Amount:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="517"/>
        <source>Rescan the complete blockchain for  Zerocoin mints and their meta-data.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="520"/>
        <source>ReScan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="547"/>
        <source>Status and/or Mesages from the last Mint Action.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="608"/>
        <source>zNPW Control</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="615"/>
        <source>zNPW Selected:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="645"/>
        <source>Quantity Selected:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="682"/>
        <source>Spend Zerocoin. Without &apos;Pay To:&apos; address creates payments to yourself.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="685"/>
        <source>Spend Zerocoin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="692"/>
        <source>Available (mature and spendable) zNPW for spending</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="695"/>
        <source>Available Balance:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="711"/>
        <source>Available (mature and spendable) zNPW for spending

zNPW are mature when they have more than 20 confirmations AND more than 2 mints of the same denomination after them were minted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="716"/>
        <location filename="../forms/privacydialog.ui" line="1137"/>
        <location filename="../forms/privacydialog.ui" line="1681"/>
        <location filename="../forms/privacydialog.ui" line="1712"/>
        <location filename="../forms/privacydialog.ui" line="1743"/>
        <location filename="../forms/privacydialog.ui" line="1774"/>
        <location filename="../forms/privacydialog.ui" line="1805"/>
        <location filename="../forms/privacydialog.ui" line="1836"/>
        <location filename="../forms/privacydialog.ui" line="1867"/>
        <location filename="../forms/privacydialog.ui" line="1898"/>
        <location filename="../forms/privacydialog.ui" line="1929"/>
        <source>0 zNPW</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="739"/>
        <source>Security Level for Zerocoin Transactions. More is better, but needs more time and resources.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="745"/>
        <source>Security Level:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="763"/>
        <source>Security Level 1 - 100 (default: 42)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="803"/>
        <source>Pay &amp;To:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="830"/>
        <source>The NPW address to send the payment to. Creates local payment to yourself when empty.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="837"/>
        <source>Choose previously used address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="847"/>
        <source>Alt+A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="854"/>
        <source>Paste address from clipboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="864"/>
        <source>Alt+P</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="879"/>
        <source>&amp;Label:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="892"/>
        <source>Enter a label for this address to add it to the list of used addresses</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="905"/>
        <source>A&amp;mount:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="968"/>
        <source>Convert Change to Zerocoin (might cost additional fees)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="975"/>
        <source>If checked, the wallet tries to minimize the returning change instead of minimizing the number of spent denominations.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="978"/>
        <source>Minimize Change</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="1025"/>
        <source>Information about the available Zerocoin funds.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="1028"/>
        <source>Zerocoin Stats:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="1096"/>
        <location filename="../forms/privacydialog.ui" line="1134"/>
        <source>Total Balance including unconfirmed and immature zNPW</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="1099"/>
        <source>Total Zerocoin  Balance:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="1151"/>
        <source>Denominations with value 1:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="1154"/>
        <source>Denom. with value 1:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="1183"/>
        <location filename="../forms/privacydialog.ui" line="1236"/>
        <location filename="../forms/privacydialog.ui" line="1289"/>
        <location filename="../forms/privacydialog.ui" line="1342"/>
        <location filename="../forms/privacydialog.ui" line="1395"/>
        <location filename="../forms/privacydialog.ui" line="1448"/>
        <location filename="../forms/privacydialog.ui" line="1501"/>
        <location filename="../forms/privacydialog.ui" line="1554"/>
        <source>Unconfirmed: less than 20 confirmations
Immature: confirmed, but less than 2 mints of the same denomination after it was minted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="1187"/>
        <location filename="../forms/privacydialog.ui" line="1240"/>
        <location filename="../forms/privacydialog.ui" line="1293"/>
        <location filename="../forms/privacydialog.ui" line="1346"/>
        <location filename="../forms/privacydialog.ui" line="1399"/>
        <location filename="../forms/privacydialog.ui" line="1452"/>
        <location filename="../forms/privacydialog.ui" line="1505"/>
        <location filename="../forms/privacydialog.ui" line="1558"/>
        <source>0 x</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="1204"/>
        <source>Denominations with value 5:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="1207"/>
        <source>Denom. with value 5:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="1257"/>
        <source>Denominations with value 10:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="1260"/>
        <source>Denom. with value 10:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="1310"/>
        <source>Denominations with value 50:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="1313"/>
        <source>Denom. with value 50:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="1363"/>
        <source>Denominations with value 100:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="1366"/>
        <source>Denom. with value 100:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="1416"/>
        <source>Denominations with value 500:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="1419"/>
        <source>Denom. with value 500:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="1469"/>
        <source>Denominations with value 1000:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="1472"/>
        <source>Denom. with value 1000:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="1522"/>
        <source>Denominations with value 5000:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="1525"/>
        <source>Denom. with value 5000:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="1594"/>
        <source>Show the current status of automatic zNPW minting.

To change the status (restart required):
- enable: add &apos;enablezeromint=1&apos; to npw.conf
- disable: add &apos;enablezeromint=0&apos; to npw.conf

To change the percentage (no restart required):
- menu Settings-&gt;Options-&gt;Percentage of autominted zNPW

</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="1606"/>
        <source>AutoMint Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="1655"/>
        <source>Global Supply:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="1692"/>
        <source>Denom. 1:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="1723"/>
        <source>Denom. 5:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="1754"/>
        <source>Denom. 10:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="1785"/>
        <source>Denom. 50:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="1816"/>
        <source>Denom. 100:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="1847"/>
        <source>Denom. 500:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="1878"/>
        <source>Denom. 1000:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="1909"/>
        <source>Denom. 5000:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="2078"/>
        <source>Priority:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="2087"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="2122"/>
        <source>Fee:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="2160"/>
        <source>Dust:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="2176"/>
        <source>no</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="2197"/>
        <source>Bytes:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="2251"/>
        <source>Insufficient funds!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="2326"/>
        <source>Coins automatically selected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="2382"/>
        <source>medium</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="2462"/>
        <source>Coin Control Features</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="2534"/>
        <source>If this is activated, but the change address is empty or invalid, change will be sent to a newly generated address.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="2537"/>
        <source>Custom change address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="2620"/>
        <source>Amount After Fee:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/privacydialog.ui" line="2660"/>
        <source>Change:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../bitcoinunits.cpp" line="252"/>
        <source>Amount</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guiutil.cpp" line="113"/>
        <source>Enter a NPW address (e.g. %1)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guiutil.cpp" line="902"/>
        <source>%1 d</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guiutil.cpp" line="904"/>
        <source>%1 h</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guiutil.cpp" line="906"/>
        <source>%1 m</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guiutil.cpp" line="908"/>
        <location filename="../guiutil.cpp" line="948"/>
        <source>%1 s</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guiutil.cpp" line="923"/>
        <source>NETWORK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guiutil.cpp" line="927"/>
        <source>BLOOM</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guiutil.cpp" line="930"/>
        <source>UNKNOWN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guiutil.cpp" line="938"/>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guiutil.cpp" line="943"/>
        <source>N/A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guiutil.cpp" line="943"/>
        <source>%1 ms</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npw.cpp" line="585"/>
        <location filename="../npw.cpp" line="592"/>
        <location filename="../npw.cpp" line="605"/>
        <location filename="../npw.cpp" line="624"/>
        <source>NPW Core</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npw.cpp" line="586"/>
        <source>Error: Specified data directory &quot;%1&quot; does not exist.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npw.cpp" line="593"/>
        <source>Error: Cannot parse configuration file: %1. Only use key=value syntax.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npw.cpp" line="605"/>
        <source>Error: Invalid combination of -regtest and -testnet.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npw.cpp" line="625"/>
        <source>Error reading masternode configuration file: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npw.cpp" line="670"/>
        <source>NPW Core didn&apos;t yet exit safely...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QRImageWidget</name>
    <message>
        <location filename="../receiverequestdialog.cpp" line="35"/>
        <source>&amp;Save Image...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../receiverequestdialog.cpp" line="38"/>
        <source>&amp;Copy Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../receiverequestdialog.cpp" line="69"/>
        <source>Save QR Code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../receiverequestdialog.cpp" line="69"/>
        <source>PNG Image (*.png)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RPCConsole</name>
    <message>
        <location filename="../forms/rpcconsole.ui" line="14"/>
        <source>Tools window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="24"/>
        <source>&amp;Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="39"/>
        <source>General</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="46"/>
        <source>Client name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="56"/>
        <location filename="../forms/rpcconsole.ui" line="79"/>
        <location filename="../forms/rpcconsole.ui" line="105"/>
        <location filename="../forms/rpcconsole.ui" line="131"/>
        <location filename="../forms/rpcconsole.ui" line="154"/>
        <location filename="../forms/rpcconsole.ui" line="177"/>
        <location filename="../forms/rpcconsole.ui" line="213"/>
        <location filename="../forms/rpcconsole.ui" line="236"/>
        <location filename="../forms/rpcconsole.ui" line="259"/>
        <location filename="../forms/rpcconsole.ui" line="295"/>
        <location filename="../forms/rpcconsole.ui" line="318"/>
        <location filename="../forms/rpcconsole.ui" line="840"/>
        <location filename="../forms/rpcconsole.ui" line="863"/>
        <location filename="../forms/rpcconsole.ui" line="886"/>
        <location filename="../forms/rpcconsole.ui" line="909"/>
        <location filename="../forms/rpcconsole.ui" line="932"/>
        <location filename="../forms/rpcconsole.ui" line="955"/>
        <location filename="../forms/rpcconsole.ui" line="978"/>
        <location filename="../forms/rpcconsole.ui" line="1001"/>
        <location filename="../forms/rpcconsole.ui" line="1024"/>
        <location filename="../forms/rpcconsole.ui" line="1047"/>
        <location filename="../forms/rpcconsole.ui" line="1070"/>
        <location filename="../forms/rpcconsole.ui" line="1093"/>
        <location filename="../forms/rpcconsole.ui" line="1116"/>
        <location filename="../forms/rpcconsole.ui" line="1139"/>
        <location filename="../forms/rpcconsole.ui" line="1162"/>
        <location filename="../forms/rpcconsole.ui" line="1188"/>
        <location filename="../forms/rpcconsole.ui" line="1211"/>
        <location filename="../forms/rpcconsole.ui" line="1302"/>
        <source>N/A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="69"/>
        <source>Client version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="92"/>
        <source>Using OpenSSL version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="118"/>
        <source>Using BerkeleyDB version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="144"/>
        <source>Build date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="167"/>
        <source>Startup time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="196"/>
        <source>Network</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="203"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="226"/>
        <source>Number of connections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="249"/>
        <source>Number of Masternodes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="278"/>
        <source>Block chain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="285"/>
        <source>Current number of blocks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="308"/>
        <source>Last block time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="350"/>
        <source>Debug log file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="357"/>
        <source>Open the NPW debug log file from the current data directory. This can take a few seconds for large log files.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="360"/>
        <source>&amp;Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="371"/>
        <source>&amp;Console</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="420"/>
        <source>Clear console</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="443"/>
        <source>&amp;Network Traffic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="495"/>
        <source>&amp;Clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="511"/>
        <source>Totals</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="575"/>
        <source>Received</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="655"/>
        <source>Sent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="696"/>
        <source>&amp;Peers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="746"/>
        <source>Banned peers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="805"/>
        <location filename="../rpcconsole.cpp" line="305"/>
        <location filename="../rpcconsole.cpp" line="1022"/>
        <source>Select a peer to view detailed information.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="830"/>
        <source>Whitelisted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="853"/>
        <source>Direction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="876"/>
        <source>Protocol</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="899"/>
        <source>Version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="922"/>
        <source>Services</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="945"/>
        <source>Starting Block</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="968"/>
        <source>Synced Headers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="991"/>
        <source>Synced Blocks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="1014"/>
        <source>Ban Score</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="1037"/>
        <source>Connection Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="1060"/>
        <source>Last Send</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="1083"/>
        <source>Last Receive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="1106"/>
        <source>Bytes Sent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="1129"/>
        <source>Bytes Received</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="1152"/>
        <source>Ping Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="1175"/>
        <source>The duration of a currently outstanding ping.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="1178"/>
        <source>Ping Wait</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="1201"/>
        <source>Time Offset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="1241"/>
        <source>&amp;Wallet Repair</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="1256"/>
        <source>Delete local Blockchain Folders</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="1269"/>
        <source>Wallet repair options.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="1282"/>
        <source>The buttons below will restart the wallet with command-line options to repair the wallet, fix issues with corrupt blockhain files or missing/obsolete transactions.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="1292"/>
        <source>Wallet In Use:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="1334"/>
        <source>Salvage wallet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="1348"/>
        <source>Attempt to recover private keys from a corrupt wallet.dat.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="1364"/>
        <source>Rescan blockchain files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="1378"/>
        <source>Rescan the block chain for missing wallet transactions.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="1394"/>
        <source>Recover transactions 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="1408"/>
        <source>Recover transactions from blockchain (keep meta-data, e.g. account owner).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="1424"/>
        <source>Recover transactions 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="1438"/>
        <source>Recover transactions from blockchain (drop meta-data).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="1454"/>
        <source>Upgrade wallet format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="1468"/>
        <source>Upgrade wallet to latest format on startup. (Note: this is NOT an update of the wallet itself!)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="1484"/>
        <source>Rebuild index</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="1498"/>
        <source>Rebuild block chain index from current blk000??.dat files.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="1521"/>
        <source>-resync:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="1528"/>
        <source>Deletes all local blockchain folders so the wallet synchronizes from scratch.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rpcconsole.cpp" line="400"/>
        <source>&amp;Disconnect Node</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rpcconsole.cpp" line="401"/>
        <location filename="../rpcconsole.cpp" line="402"/>
        <location filename="../rpcconsole.cpp" line="403"/>
        <location filename="../rpcconsole.cpp" line="404"/>
        <source>Ban Node for</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rpcconsole.cpp" line="401"/>
        <source>1 &amp;hour</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rpcconsole.cpp" line="402"/>
        <source>1 &amp;day</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rpcconsole.cpp" line="403"/>
        <source>1 &amp;week</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rpcconsole.cpp" line="404"/>
        <source>1 &amp;year</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rpcconsole.cpp" line="450"/>
        <source>&amp;Unban Node</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rpcconsole.cpp" line="545"/>
        <source>This will delete your local blockchain folders and the wallet will synchronize the complete Blockchain from scratch.&lt;br /&gt;&lt;br /&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rpcconsole.cpp" line="546"/>
        <source>This needs quite some time and downloads a lot of data.&lt;br /&gt;&lt;br /&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rpcconsole.cpp" line="547"/>
        <source>Your transactions and funds will be visible again after the download has completed.&lt;br /&gt;&lt;br /&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rpcconsole.cpp" line="548"/>
        <source>Do you want to continue?.&lt;br /&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rpcconsole.cpp" line="549"/>
        <source>Confirm resync Blockchain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rpcconsole.cpp" line="611"/>
        <source>Welcome to the NPW RPC console.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rpcconsole.cpp" line="612"/>
        <source>Use up and down arrows to navigate history, and &lt;b&gt;Ctrl-L&lt;/b&gt; to clear screen.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rpcconsole.cpp" line="613"/>
        <source>Type &lt;b&gt;help&lt;/b&gt; for an overview of available commands.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rpcconsole.cpp" line="646"/>
        <source>In:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rpcconsole.cpp" line="647"/>
        <source>Out:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rpcconsole.cpp" line="753"/>
        <source>%1 B</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rpcconsole.cpp" line="755"/>
        <source>%1 KB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rpcconsole.cpp" line="757"/>
        <source>%1 MB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rpcconsole.cpp" line="759"/>
        <source>%1 GB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rpcconsole.cpp" line="882"/>
        <source>(node id: %1)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rpcconsole.cpp" line="884"/>
        <source>via %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rpcconsole.cpp" line="887"/>
        <location filename="../rpcconsole.cpp" line="888"/>
        <source>never</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rpcconsole.cpp" line="897"/>
        <source>Inbound</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rpcconsole.cpp" line="897"/>
        <source>Outbound</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rpcconsole.cpp" line="899"/>
        <source>Yes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rpcconsole.cpp" line="899"/>
        <source>No</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../rpcconsole.cpp" line="911"/>
        <location filename="../rpcconsole.cpp" line="917"/>
        <source>Unknown</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ReceiveCoinsDialog</name>
    <message>
        <location filename="../forms/receivecoinsdialog.ui" line="58"/>
        <source>RECEIVE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/receivecoinsdialog.ui" line="142"/>
        <source>Reuse one of the previously used receiving addresses.&lt;br&gt;Reusing addresses has security and privacy issues.&lt;br&gt;Do not use this unless re-generating a payment request made before.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/receivecoinsdialog.ui" line="145"/>
        <source>R&amp;euse an existing receiving address (not recommended)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/receivecoinsdialog.ui" line="159"/>
        <source>An optional message to attach to the payment request, which will be displayed when the request is opened. Note: The message will not be sent with the payment over the NPW network.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/receivecoinsdialog.ui" line="162"/>
        <source>&amp;Message:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/receivecoinsdialog.ui" line="175"/>
        <location filename="../forms/receivecoinsdialog.ui" line="196"/>
        <source>An optional label to associate with the new receiving address.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/receivecoinsdialog.ui" line="182"/>
        <source>An optional message to attach to the payment request, which will be displayed when the request is opened.&lt;br&gt;Note: The message will not be sent with the payment over the NPW network.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/receivecoinsdialog.ui" line="189"/>
        <source>Use this form to request payments. All fields are &lt;b&gt;optional&lt;/b&gt;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/receivecoinsdialog.ui" line="199"/>
        <source>&amp;Label:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/receivecoinsdialog.ui" line="212"/>
        <location filename="../forms/receivecoinsdialog.ui" line="234"/>
        <source>An optional amount to request. Leave this empty or zero to not request a specific amount.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/receivecoinsdialog.ui" line="215"/>
        <source>&amp;Amount:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/receivecoinsdialog.ui" line="256"/>
        <source>&amp;Request payment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/receivecoinsdialog.ui" line="273"/>
        <source>Clear all fields of the form.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/receivecoinsdialog.ui" line="276"/>
        <source>Clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/receivecoinsdialog.ui" line="344"/>
        <source>Requested payments history</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/receivecoinsdialog.ui" line="406"/>
        <source>Show the selected request (does the same as double clicking an entry)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/receivecoinsdialog.ui" line="409"/>
        <source>Show</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/receivecoinsdialog.ui" line="426"/>
        <source>Remove the selected entries from the list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/receivecoinsdialog.ui" line="429"/>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../receivecoinsdialog.cpp" line="38"/>
        <source>Copy label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../receivecoinsdialog.cpp" line="39"/>
        <source>Copy message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../receivecoinsdialog.cpp" line="40"/>
        <source>Copy amount</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ReceiveRequestDialog</name>
    <message>
        <location filename="../forms/receiverequestdialog.ui" line="29"/>
        <source>QR Code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/receiverequestdialog.ui" line="75"/>
        <source>Copy &amp;URI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/receiverequestdialog.ui" line="85"/>
        <source>Copy &amp;Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/receiverequestdialog.ui" line="95"/>
        <source>&amp;Save Image...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../receiverequestdialog.cpp" line="132"/>
        <source>Request payment to %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../receiverequestdialog.cpp" line="138"/>
        <source>Payment information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../receiverequestdialog.cpp" line="139"/>
        <source>URI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../receiverequestdialog.cpp" line="141"/>
        <source>Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../receiverequestdialog.cpp" line="143"/>
        <source>Amount</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../receiverequestdialog.cpp" line="145"/>
        <source>Label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../receiverequestdialog.cpp" line="147"/>
        <source>Message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../receiverequestdialog.cpp" line="155"/>
        <source>Resulting URI too long, try to reduce the text for label / message.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../receiverequestdialog.cpp" line="159"/>
        <source>Error encoding URI into QR Code.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RecentRequestsTableModel</name>
    <message>
        <location filename="../recentrequeststablemodel.cpp" line="27"/>
        <source>Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../recentrequeststablemodel.cpp" line="27"/>
        <source>Label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../recentrequeststablemodel.cpp" line="27"/>
        <source>Message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../recentrequeststablemodel.cpp" line="64"/>
        <source>(no label)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../recentrequeststablemodel.cpp" line="70"/>
        <source>(no message)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../recentrequeststablemodel.cpp" line="76"/>
        <source>(no amount)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../recentrequeststablemodel.cpp" line="114"/>
        <source>Amount</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SendCoinsDialog</name>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="17"/>
        <location filename="../sendcoinsdialog.cpp" line="231"/>
        <location filename="../sendcoinsdialog.cpp" line="256"/>
        <location filename="../sendcoinsdialog.cpp" line="652"/>
        <source>Send Coins</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="82"/>
        <source>SEND</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="238"/>
        <source>Coin Control Features</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="279"/>
        <source>Open Coin Control...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="289"/>
        <source>Coins automatically selected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="308"/>
        <source>Insufficient funds!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="397"/>
        <source>Quantity:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="432"/>
        <source>Bytes:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="480"/>
        <source>Amount:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="512"/>
        <source>Priority:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="525"/>
        <source>medium</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="560"/>
        <source>Fee:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="592"/>
        <source>Dust:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="605"/>
        <source>no</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="640"/>
        <source>After Fee:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="672"/>
        <source>Change:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="734"/>
        <source>If this is activated, but the change address is empty or invalid, change will be sent to a newly generated address.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="737"/>
        <source>Custom change address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="813"/>
        <source>Split UTXO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="838"/>
        <source># of outputs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="845"/>
        <source>UTXO Size:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="852"/>
        <source>0 NPW</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="1040"/>
        <source>Transaction Fee:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="1054"/>
        <source>Choose...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="1061"/>
        <source>collapse fee-settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="1064"/>
        <source>Minimize</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="1179"/>
        <source>Custom:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="1196"/>
        <source>If the custom fee is set to 1000 uNPWs and the transaction is only 250 bytes, then &quot;per kilobyte&quot; only pays 250 uNPWs in fee,&lt;br /&gt;while &quot;at least&quot; pays 1000 uNPWs. For transactions bigger than a kilobyte both pay by kilobyte.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="1199"/>
        <source>per kilobyte</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="1212"/>
        <source>If the custom fee is set to 1000 uNPWs and the transaction is only 250 bytes, then &quot;per kilobyte&quot; only pays 250 uNPWs in fee,&lt;br /&gt;while &quot;total at least&quot; pays 1000 uNPWs. For transactions bigger than a kilobyte both pay by kilobyte.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="1215"/>
        <source>total at least</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="1245"/>
        <location filename="../forms/sendcoinsdialog.ui" line="1258"/>
        <source>Paying only the minimum fee is just fine as long as there is less transaction volume than space in the blocks.&lt;br /&gt;But be aware that this can end up in a never confirming transaction once there is more demand for NPW transactions than the network can process.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="1261"/>
        <source>(read the tooltip)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="1288"/>
        <source>Recommended</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="1308"/>
        <source>Confirmation time:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="1318"/>
        <source>normal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="1362"/>
        <source>fast</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="1399"/>
        <source>(Smart fee not initialized yet. This usually takes a few blocks...)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="1530"/>
        <source>Send as zero-fee transaction if possible</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="1537"/>
        <source>(confirmation may take longer)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="1608"/>
        <source>Confirm the send action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="1611"/>
        <source>S&amp;end</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="1634"/>
        <source>Clear all fields of the form.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="1637"/>
        <source>Clear &amp;All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="1651"/>
        <source>Send to multiple recipients at once</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="1654"/>
        <source>Add &amp;Recipient</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="1689"/>
        <source>Anonymized NPW</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="1705"/>
        <source>SwiftX</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="1712"/>
        <source>Balance:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="82"/>
        <source>Copy quantity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="83"/>
        <source>Copy amount</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="84"/>
        <source>Copy fee</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="85"/>
        <source>Copy after fee</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="86"/>
        <source>Copy bytes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="87"/>
        <source>Copy priority</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="88"/>
        <source>Copy dust</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="89"/>
        <source>Copy change</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="232"/>
        <source>The split block tool does not work when sending to outside addresses. Try again.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="257"/>
        <source>The split block tool does not work with multiple addresses. Try again.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="272"/>
        <source>using SwiftX</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="295"/>
        <location filename="../sendcoinsdialog.cpp" line="299"/>
        <location filename="../sendcoinsdialog.cpp" line="303"/>
        <location filename="../sendcoinsdialog.cpp" line="306"/>
        <source>%1 to %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="310"/>
        <source> split into %1 outputs using the UTXO splitter.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="357"/>
        <source>Are you sure you want to send?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="365"/>
        <source>are added as transaction fee</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="383"/>
        <source>Total Amount = &lt;b&gt;%1&lt;/b&gt;&lt;br /&gt;= %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="399"/>
        <source>&lt;b&gt;(%1 of %2 entries displayed)&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="402"/>
        <source>Confirm send coins</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="601"/>
        <source>The recipient address is not valid, please recheck.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="604"/>
        <source>The amount to pay must be larger than 0.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="607"/>
        <source>The amount exceeds your balance.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="610"/>
        <source>The total exceeds your balance when the %1 transaction fee is included.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="613"/>
        <source>Duplicate address found, can only send to each address once per send operation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="616"/>
        <source>Transaction creation failed!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="620"/>
        <source>The transaction was rejected! This might happen if some of the coins in your wallet were already spent, such as if you used a copy of wallet.dat and coins were spent in the copy but not marked as spent here.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="628"/>
        <source>Error: The wallet was unlocked only to anonymize coins.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="632"/>
        <source>A fee %1 times higher than %2 per kB is considered an insanely high fee.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="644"/>
        <source>Error: The wallet was unlocked only to anonymize coins. Unlock canceled.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="728"/>
        <source>Pay only the minimum fee of %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message numerus="yes">
        <location filename="../sendcoinsdialog.cpp" line="746"/>
        <source>Estimated to begin confirmation within %n block(s).</source>
        <translation type="unfinished">
            <numerusform></numerusform>
            <numerusform></numerusform>
        </translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="886"/>
        <source>Warning: Invalid NPW address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="894"/>
        <source>Warning: Unknown change address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="904"/>
        <source>(no label)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SendCoinsEntry</name>
    <message>
        <location filename="../forms/sendcoinsentry.ui" line="21"/>
        <source>This is a normal payment.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsentry.ui" line="36"/>
        <source>Pay &amp;To:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsentry.ui" line="54"/>
        <source>The NPW address to send the payment to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsentry.ui" line="61"/>
        <source>Choose previously used address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsentry.ui" line="71"/>
        <source>Alt+A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsentry.ui" line="78"/>
        <source>Paste address from clipboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsentry.ui" line="88"/>
        <source>Alt+P</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsentry.ui" line="95"/>
        <location filename="../forms/sendcoinsentry.ui" line="619"/>
        <location filename="../forms/sendcoinsentry.ui" line="1155"/>
        <source>Remove this entry</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsentry.ui" line="111"/>
        <source>&amp;Label:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsentry.ui" line="124"/>
        <source>Enter a label for this address to add it to the list of used addresses</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsentry.ui" line="131"/>
        <location filename="../forms/sendcoinsentry.ui" line="652"/>
        <location filename="../forms/sendcoinsentry.ui" line="1188"/>
        <source>A&amp;mount:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsentry.ui" line="147"/>
        <source>Message:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsentry.ui" line="157"/>
        <source>A message that was attached to the NPW: URI which will be stored with the transaction for your reference. Note: This message will not be sent over the NPW network.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsentry.ui" line="583"/>
        <source>This is an unverified payment request.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsentry.ui" line="601"/>
        <location filename="../forms/sendcoinsentry.ui" line="1133"/>
        <source>Pay To:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsentry.ui" line="635"/>
        <location filename="../forms/sendcoinsentry.ui" line="1171"/>
        <source>Memo:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsentry.ui" line="1115"/>
        <source>This is a verified payment request.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sendcoinsentry.cpp" line="31"/>
        <source>Enter a label for this address to add it to your address book</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ShutdownWindow</name>
    <message>
        <location filename="../utilitydialog.cpp" line="157"/>
        <source>NPW Core is shutting down...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../utilitydialog.cpp" line="158"/>
        <source>Do not shut down the computer until this window disappears.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SignVerifyMessageDialog</name>
    <message>
        <location filename="../forms/signverifymessagedialog.ui" line="14"/>
        <source>Signatures - Sign / Verify a Message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/signverifymessagedialog.ui" line="27"/>
        <source>&amp;Sign Message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/signverifymessagedialog.ui" line="33"/>
        <source>You can sign messages with your addresses to prove you own them. Be careful not to sign anything vague, as phishing attacks may try to trick you into signing your identity over to them. Only sign fully-detailed statements you agree to.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/signverifymessagedialog.ui" line="48"/>
        <source>The NPW address to sign the message with</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/signverifymessagedialog.ui" line="55"/>
        <location filename="../forms/signverifymessagedialog.ui" line="250"/>
        <source>Choose previously used address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/signverifymessagedialog.ui" line="65"/>
        <location filename="../forms/signverifymessagedialog.ui" line="260"/>
        <source>Alt+A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/signverifymessagedialog.ui" line="72"/>
        <source>Paste address from clipboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/signverifymessagedialog.ui" line="82"/>
        <source>Alt+P</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/signverifymessagedialog.ui" line="91"/>
        <source>Enter the message you want to sign here</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/signverifymessagedialog.ui" line="98"/>
        <source>Signature</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/signverifymessagedialog.ui" line="122"/>
        <source>Copy the current signature to the system clipboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/signverifymessagedialog.ui" line="140"/>
        <source>Sign the message to prove you own this NPW address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/signverifymessagedialog.ui" line="143"/>
        <source>Sign &amp;Message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/signverifymessagedialog.ui" line="157"/>
        <source>Reset all sign message fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/signverifymessagedialog.ui" line="160"/>
        <location filename="../forms/signverifymessagedialog.ui" line="297"/>
        <source>Clear &amp;All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/signverifymessagedialog.ui" line="219"/>
        <source>&amp;Verify Message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/signverifymessagedialog.ui" line="225"/>
        <source>Enter the signing address, message (ensure you copy line breaks, spaces, tabs, etc. exactly) and signature below to verify the message. Be careful not to read more into the signature than what is in the signed message itself, to avoid being tricked by a man-in-the-middle attack.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/signverifymessagedialog.ui" line="243"/>
        <source>The NPW address the message was signed with</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/signverifymessagedialog.ui" line="277"/>
        <source>Verify the message to ensure it was signed with the specified NPW address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/signverifymessagedialog.ui" line="280"/>
        <source>Verify &amp;Message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/signverifymessagedialog.ui" line="294"/>
        <source>Reset all verify message fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../signverifymessagedialog.cpp" line="31"/>
        <source>Click &quot;Sign Message&quot; to generate signature</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../signverifymessagedialog.cpp" line="111"/>
        <location filename="../signverifymessagedialog.cpp" line="184"/>
        <source>The entered address is invalid.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../signverifymessagedialog.cpp" line="111"/>
        <location filename="../signverifymessagedialog.cpp" line="118"/>
        <location filename="../signverifymessagedialog.cpp" line="184"/>
        <location filename="../signverifymessagedialog.cpp" line="191"/>
        <source>Please check the address and try again.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../signverifymessagedialog.cpp" line="118"/>
        <location filename="../signverifymessagedialog.cpp" line="191"/>
        <source>The entered address does not refer to a key.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../signverifymessagedialog.cpp" line="125"/>
        <source>Wallet unlock was cancelled.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../signverifymessagedialog.cpp" line="132"/>
        <source>Private key for the entered address is not available.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../signverifymessagedialog.cpp" line="143"/>
        <source>Message signing failed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../signverifymessagedialog.cpp" line="148"/>
        <source>Message signed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../signverifymessagedialog.cpp" line="201"/>
        <source>The signature could not be decoded.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../signverifymessagedialog.cpp" line="201"/>
        <location filename="../signverifymessagedialog.cpp" line="213"/>
        <source>Please check the signature and try again.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../signverifymessagedialog.cpp" line="213"/>
        <source>The signature did not match the message digest.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../signverifymessagedialog.cpp" line="219"/>
        <source>Message verification failed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../signverifymessagedialog.cpp" line="224"/>
        <source>Message verified.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SplashScreen</name>
    <message>
        <location filename="../networkstyle.cpp" line="19"/>
        <source>[testnet]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../splashscreen.cpp" line="36"/>
        <source>NPW Core</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../splashscreen.cpp" line="37"/>
        <source>Version %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../splashscreen.cpp" line="38"/>
        <source>The Bitcoin Core developers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../splashscreen.cpp" line="39"/>
        <source>The Dash Core developers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../splashscreen.cpp" line="40"/>
        <source>The PIVX Core developers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../splashscreen.cpp" line="41"/>
        <source>The NPW Core developers</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TrafficGraphWidget</name>
    <message>
        <location filename="../trafficgraphwidget.cpp" line="78"/>
        <source>KB/s</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TransactionDesc</name>
    <message numerus="yes">
        <location filename="../transactiondesc.cpp" line="33"/>
        <source>Open for %n more block(s)</source>
        <translation type="unfinished">
            <numerusform></numerusform>
            <numerusform></numerusform>
        </translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="35"/>
        <source>Open until %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="43"/>
        <location filename="../transactiondesc.cpp" line="54"/>
        <location filename="../transactiondesc.cpp" line="64"/>
        <location filename="../transactiondesc.cpp" line="76"/>
        <source>conflicted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="45"/>
        <source>%1/offline (verified via SwiftX)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="47"/>
        <source>%1/confirmed (verified via SwiftX)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="49"/>
        <source>%1 confirmations (verified via SwiftX)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="56"/>
        <source>%1/offline (SwiftX verification in progress - %2 of %3 signatures)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="58"/>
        <source>%1/confirmed (SwiftX verification in progress - %2 of %3 signatures )</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="60"/>
        <source>%1 confirmations (SwiftX verification in progress - %2 of %3 signatures)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="66"/>
        <source>%1/offline (SwiftX verification failed)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="68"/>
        <source>%1/confirmed (SwiftX verification failed)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="70"/>
        <location filename="../transactiondesc.cpp" line="82"/>
        <source>%1 confirmations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="78"/>
        <source>%1/offline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="80"/>
        <source>%1/unconfirmed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="100"/>
        <source>Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="104"/>
        <source>, has not been successfully broadcast yet</source>
        <translation type="unfinished"></translation>
    </message>
    <message numerus="yes">
        <location filename="../transactiondesc.cpp" line="106"/>
        <source>, broadcast through %n node(s)</source>
        <translation type="unfinished">
            <numerusform></numerusform>
            <numerusform></numerusform>
        </translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="110"/>
        <source>Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="116"/>
        <source>Source</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="116"/>
        <source>Generated</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="119"/>
        <location filename="../transactiondesc.cpp" line="127"/>
        <location filename="../transactiondesc.cpp" line="190"/>
        <source>From</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="127"/>
        <source>unknown</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="128"/>
        <location filename="../transactiondesc.cpp" line="147"/>
        <location filename="../transactiondesc.cpp" line="205"/>
        <source>To</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="130"/>
        <source>own address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="130"/>
        <location filename="../transactiondesc.cpp" line="190"/>
        <source>watch-only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="132"/>
        <source>label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="164"/>
        <location filename="../transactiondesc.cpp" line="174"/>
        <location filename="../transactiondesc.cpp" line="219"/>
        <location filename="../transactiondesc.cpp" line="242"/>
        <location filename="../transactiondesc.cpp" line="292"/>
        <source>Credit</source>
        <translation type="unfinished"></translation>
    </message>
    <message numerus="yes">
        <location filename="../transactiondesc.cpp" line="166"/>
        <source>matures in %n more block(s)</source>
        <translation type="unfinished">
            <numerusform></numerusform>
            <numerusform></numerusform>
        </translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="168"/>
        <source>not accepted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="217"/>
        <location filename="../transactiondesc.cpp" line="239"/>
        <location filename="../transactiondesc.cpp" line="289"/>
        <source>Debit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="226"/>
        <source>Total debit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="227"/>
        <source>Total credit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="232"/>
        <source>Transaction fee</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="246"/>
        <source>Net amount</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="252"/>
        <location filename="../transactiondesc.cpp" line="262"/>
        <source>Message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="254"/>
        <source>Comment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="256"/>
        <source>Transaction ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="257"/>
        <source>Output index</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="273"/>
        <source>Merchant</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="279"/>
        <source>Generated coins must mature %1 blocks before they can be spent. When you generated this block, it was broadcast to the network to be added to the block chain. If it fails to get into the chain, its state will change to &quot;not accepted&quot; and it won&apos;t be spendable. This may occasionally happen if another node generates a block within a few seconds of yours.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="286"/>
        <source>Debug information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="294"/>
        <source>Transaction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="297"/>
        <source>Inputs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="314"/>
        <source>Amount</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="315"/>
        <location filename="../transactiondesc.cpp" line="316"/>
        <source>true</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="315"/>
        <location filename="../transactiondesc.cpp" line="316"/>
        <source>false</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TransactionDescDialog</name>
    <message>
        <location filename="../forms/transactiondescdialog.ui" line="14"/>
        <source>Transaction details</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/transactiondescdialog.ui" line="20"/>
        <source>This pane shows a detailed description of the transaction</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TransactionTableModel</name>
    <message>
        <location filename="../transactiontablemodel.cpp" line="213"/>
        <source>Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="213"/>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="213"/>
        <source>Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message numerus="yes">
        <location filename="../transactiontablemodel.cpp" line="270"/>
        <source>Open for %n more block(s)</source>
        <translation type="unfinished">
            <numerusform></numerusform>
            <numerusform></numerusform>
        </translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="273"/>
        <source>Open until %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="276"/>
        <source>Offline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="279"/>
        <source>Unconfirmed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="282"/>
        <source>Confirming (%1 of %2 recommended confirmations)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="285"/>
        <source>Confirmed (%1 confirmations)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="288"/>
        <source>Conflicted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="291"/>
        <source>Immature (%1 confirmations, will be available after %2)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="294"/>
        <source>This block was not received by any other nodes and will probably not be accepted!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="297"/>
        <source>Orphan Block - Generated but not accepted. This does not impact your holdings.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="332"/>
        <source>Received with</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="334"/>
        <source>Masternode Reward</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="336"/>
        <source>Received from</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="338"/>
        <source>Received via Obfuscation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="341"/>
        <source>Sent to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="343"/>
        <source>Payment to yourself</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="345"/>
        <source>Minted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="347"/>
        <source>Mined</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="349"/>
        <source>Obfuscation Denominate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="351"/>
        <source>Obfuscation Collateral Payment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="353"/>
        <source>Obfuscation Make Collateral Inputs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="355"/>
        <source>Obfuscation Create Denominations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="357"/>
        <source>Obfuscated</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="359"/>
        <source>Converted NPW to zNPW</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="361"/>
        <source>Spent zNPW</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="363"/>
        <source>Received NPW from zNPW</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="365"/>
        <source>Minted Change as zNPW from zNPW Spend</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="367"/>
        <source>Converted zNPW to NPW</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="400"/>
        <source>watch-only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="422"/>
        <source>zNPW Accumulator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="425"/>
        <source>(n/a)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="629"/>
        <source>Transaction status. Hover over this field to show number of confirmations.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="631"/>
        <source>Date and time that the transaction was received.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="633"/>
        <source>Type of transaction.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="635"/>
        <source>Whether or not a watch-only address is involved in this transaction.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="637"/>
        <source>Destination address of transaction.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="639"/>
        <source>Amount removed from or added to balance.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TransactionView</name>
    <message>
        <location filename="../transactionview.cpp" line="68"/>
        <location filename="../transactionview.cpp" line="85"/>
        <source>All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="69"/>
        <source>Today</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="70"/>
        <source>This week</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="71"/>
        <source>This month</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="72"/>
        <source>Last month</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="73"/>
        <source>This year</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="74"/>
        <source>Range...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="86"/>
        <source>Most Common</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="87"/>
        <source>Received with</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="88"/>
        <source>Sent to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="99"/>
        <source>To yourself</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="100"/>
        <source>Mined</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="101"/>
        <source>Minted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="102"/>
        <source>Masternode Reward</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="103"/>
        <source>Received NPW from zNPW</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="104"/>
        <source>Zerocoin Mint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="105"/>
        <source>Zerocoin Spend</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="106"/>
        <source>Zerocoin Spend, Change in zNPW</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="107"/>
        <source>Zerocoin Spend to Self</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="108"/>
        <source>Other</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="115"/>
        <source>Enter address or label to search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="121"/>
        <source>Min amount</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="157"/>
        <source>Copy address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="158"/>
        <source>Copy label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="159"/>
        <source>Copy amount</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="160"/>
        <source>Copy transaction ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="161"/>
        <source>Edit label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="162"/>
        <source>Show transaction details</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="357"/>
        <source>Export Transaction History</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="358"/>
        <source>Comma separated file (*.csv)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="369"/>
        <source>Confirmed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="371"/>
        <source>Watch-only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="372"/>
        <source>Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="373"/>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="374"/>
        <source>Label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="375"/>
        <source>Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="377"/>
        <source>ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="383"/>
        <source>Exporting Successful</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="383"/>
        <source>The transaction history was successfully saved to %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="387"/>
        <source>Exporting Failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="387"/>
        <source>There was an error trying to save the transaction history to %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="504"/>
        <source>Range:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="512"/>
        <source>to</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UnitDisplayStatusBarControl</name>
    <message>
        <location filename="../bitcoingui.cpp" line="1355"/>
        <source>Unit to show amounts in. Click to select another unit.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WalletFrame</name>
    <message>
        <location filename="../walletframe.cpp" line="25"/>
        <source>No wallet has been loaded.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WalletModel</name>
    <message>
        <location filename="../walletmodel.cpp" line="331"/>
        <location filename="../walletmodel.cpp" line="340"/>
        <location filename="../walletmodel.cpp" line="349"/>
        <source>Send Coins</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../walletmodel.cpp" line="331"/>
        <location filename="../walletmodel.cpp" line="340"/>
        <source>SwiftX doesn&apos;t support sending values that high yet. Transactions are currently limited to %1 NPW.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WalletView</name>
    <message>
        <location filename="../walletview.cpp" line="62"/>
        <source>HISTORY</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../walletview.cpp" line="94"/>
        <source>&amp;Export</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../walletview.cpp" line="95"/>
        <source>Export the data in the current tab to a file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../walletview.cpp" line="104"/>
        <source>Selected amount:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../walletview.cpp" line="361"/>
        <source>Backup Wallet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../walletview.cpp" line="362"/>
        <source>Wallet Data (*.dat)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../walletview.cpp" line="368"/>
        <source>Backup Failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../walletview.cpp" line="368"/>
        <source>There was an error trying to save the wallet data to %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../walletview.cpp" line="371"/>
        <source>Backup Successful</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../walletview.cpp" line="371"/>
        <source>The wallet data was successfully saved to %1.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>npw-core</name>
    <message>
        <location filename="../npwstrings.cpp" line="12"/>
        <source> mints deleted
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="13"/>
        <source> mints updated, </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="14"/>
        <source> unconfirmed transactions removed
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="15"/>
        <source>(1 = keep tx meta data e.g. account owner and payment request information, 2 = drop tx meta data)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="18"/>
        <source>Allow JSON-RPC connections from specified source. Valid for &lt;ip&gt; are a single IP (e.g. 1.2.3.4), a network/netmask (e.g. 1.2.3.4/255.255.255.0) or a network/CIDR (e.g. 1.2.3.4/24). This option can be specified multiple times</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="22"/>
        <source>An error occurred while setting up the RPC address %s port %u for listening: %s</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="25"/>
        <source>Bind to given address and always listen on it. Use [host]:port notation for IPv6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="28"/>
        <source>Bind to given address and whitelist peers connecting to it. Use [host]:port notation for IPv6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="31"/>
        <source>Bind to given address to listen for JSON-RPC connections. Use [host]:port notation for IPv6. This option can be specified multiple times (default: bind to all interfaces)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="35"/>
        <source>Calculated accumulator checkpoint is not what is recorded by block index</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="37"/>
        <source>Cannot obtain a lock on data directory %s. NPW Core is probably already running.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="40"/>
        <source>Change automatic finalized budget voting behavior. mode=auto: Vote for only exact finalized budget match to my generated budget. (string, default: auto)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="43"/>
        <source>Continuously rate-limit free transactions to &lt;n&gt;*1000 bytes per minute (default:%u)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="46"/>
        <source>Create new files with system default permissions, instead of umask 077 (only effective with disabled wallet functionality)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="49"/>
        <source>Delete all wallet transactions and only recover those parts of the blockchain through -rescan on startup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="52"/>
        <source>Disable all NPW specific functionality (Masternodes, Zerocoin, SwiftX, Budgeting) (0-1, default: %u)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="55"/>
        <source>Distributed under the MIT software license, see the accompanying file COPYING or &lt;http://www.opensource.org/licenses/mit-license.php&gt;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="58"/>
        <source>Enable SwiftX, show confirmations for locked transactions (bool, default: %s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="60"/>
        <source>Enable automatic wallet backups triggered after each zNPW minting (0-1, default: %u)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="63"/>
        <source>Enable spork administration functionality with the appropriate private key.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="65"/>
        <source>Enter regression test mode, which uses a special chain in which blocks can be solved instantly.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="68"/>
        <source>Error: Listening for incoming connections failed (listen returned error %s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="70"/>
        <source>Error: The transaction was rejected! This might happen if some of the coins in your wallet were already spent, such as if you used a copy of wallet.dat and coins were spent in the copy but not marked as spent here.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="74"/>
        <source>Error: This transaction requires a transaction fee of at least %s because of its amount, complexity, or use of recently received funds!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="77"/>
        <source>Error: Unsupported argument -checklevel found. Checklevel must be level 4.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="79"/>
        <source>Error: Unsupported argument -socks found. Setting SOCKS version isn&apos;t possible anymore, only SOCKS5 proxies are supported.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="82"/>
        <source>Execute command when a relevant alert is received or we see a really long fork (%s in cmd is replaced by message)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="85"/>
        <source>Execute command when a wallet transaction changes (%s in cmd is replaced by TxID)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="88"/>
        <source>Execute command when the best block changes (%s in cmd is replaced by block hash)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="91"/>
        <source>Fees (in NPW/Kb) smaller than this are considered zero fee for relaying (default: %s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="94"/>
        <source>Fees (in NPW/Kb) smaller than this are considered zero fee for transaction creation (default: %s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="97"/>
        <source>Flush database activity from memory pool to disk log every &lt;n&gt; megabytes (default: %u)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="100"/>
        <source>Found unconfirmed denominated outputs, will wait till they confirm to continue.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="103"/>
        <source>If paytxfee is not set, include enough fee so transactions begin confirmation on average within n blocks (default: %u)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="106"/>
        <source>In this mode -genproclimit controls how many blocks are generated immediately.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="109"/>
        <source>Insufficient or insufficient confirmed funds, you might need to wait a few minutes and try again.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="112"/>
        <source>Invalid amount for -maxtxfee=&lt;amount&gt;: &apos;%s&apos; (must be at least the minrelay fee of %s to prevent stuck transactions)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="115"/>
        <source>Keep the specified amount available for spending at all times (default: 0)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="117"/>
        <source>Log transaction priority and fee per kB when mining blocks (default: %u)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="119"/>
        <source>Maintain a full transaction index, used by the getrawtransaction rpc call (default: %u)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="122"/>
        <source>Maximum size of data in data carrier transactions we relay and mine (default: %u)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="125"/>
        <source>Maximum total fees to use in a single wallet transaction, setting too low may abort large transactions (default: %s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="128"/>
        <source>Number of seconds to keep misbehaving peers from reconnecting (default: %u)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="130"/>
        <source>Obfuscation uses exact denominated amounts to send funds, you might simply need to anonymize some more coins.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="133"/>
        <source>Output debugging information (default: %u, supplying &lt;category&gt; is optional)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="135"/>
        <source>Preferred Denomination for automatically minted Zerocoin  (1/5/10/50/100/500/1000/5000), 0 for no preference. default: %u)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="138"/>
        <source>Query for peer addresses via DNS lookup, if low on addresses (default: 1 unless -connect)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="141"/>
        <source>Randomize credentials for every proxy connection. This enables Tor stream isolation (default: %u)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="144"/>
        <source>Require high priority for relaying free or low-fee transactions (default:%u)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="146"/>
        <source>Send trace/debug info to console instead of debug.log file (default: %u)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="148"/>
        <source>Set maximum size of high-priority/low-fee transactions in bytes (default: %d)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="150"/>
        <source>Set the number of script verification threads (%u to %d, 0 = auto, &lt;0 = leave that many cores free, default: %d)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="153"/>
        <source>Set the number of threads for coin generation if enabled (-1 = all cores, default: %d)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="156"/>
        <source>Show N confirmations for a successfully locked transaction (0-9999, default: %u)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="159"/>
        <source>Support filtering of blocks and transaction with bloom filters (default: %u)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="161"/>
        <source>SwiftX requires inputs with at least 6 confirmations, you might need to wait a few minutes and try again.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="164"/>
        <source>This is a pre-release test build - use at your own risk - do not use for staking or merchant applications!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="167"/>
        <source>This product includes software developed by the OpenSSL Project for use in the OpenSSL Toolkit &lt;https://www.openssl.org/&gt; and cryptographic software written by Eric Young and UPnP software written by Thomas Bernard.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="171"/>
        <source>To use npwd, or the -server option to npw-qt, you must set an rpcpassword in the configuration file:
%s
It is recommended you use the following random password:
rpcuser=npwrpc
rpcpassword=%s
(you do not need to remember this password)
The username and password MUST NOT be the same.
If the file does not exist, create it with owner-readable-only file permissions.
It is also recommended to set alertnotify so you are notified of problems;
for example: alertnotify=echo %%s | mail -s &quot;NPW Alert&quot; admin@foo.com
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="184"/>
        <source>Unable to bind to %s on this computer. NPW Core is probably already running.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="186"/>
        <source>Unable to locate enough Obfuscation denominated funds for this transaction.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="188"/>
        <source>Unable to locate enough Obfuscation non-denominated funds for this transaction that are not equal 10000 NPW.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="191"/>
        <source>Unable to locate enough funds for this transaction that are not equal 10000 NPW.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="194"/>
        <source>Use separate SOCKS5 proxy to reach peers via Tor hidden services (default: %s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="197"/>
        <source>Warning: -maxtxfee is set very high! Fees this large could be paid on a single transaction.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="200"/>
        <source>Warning: -paytxfee is set very high! This is the transaction fee you will pay if you send a transaction.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="203"/>
        <source>Warning: Please check that your computer&apos;s date and time are correct! If your clock is wrong NPW Core will not work properly.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="206"/>
        <source>Warning: The network does not appear to fully agree! Some miners appear to be experiencing issues.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="209"/>
        <source>Warning: We do not appear to fully agree with our peers! You may need to upgrade, or other nodes may need to upgrade.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="212"/>
        <source>Warning: error reading wallet.dat! All keys read correctly, but transaction data or address book entries might be missing or incorrect.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="215"/>
        <source>Warning: wallet.dat corrupt, data salvaged! Original wallet.dat saved as wallet.{timestamp}.bak in %s; if your balance or transactions are incorrect you should restore from a backup.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="219"/>
        <source>Whitelist peers connecting from the given netmask or IP address. Can be specified multiple times.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="222"/>
        <source>Whitelisted peers cannot be DoS banned and their transactions are always relayed, even if they are already in the mempool, useful e.g. for a gateway</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="225"/>
        <source>You must specify a masternodeprivkey in the configuration. Please see documentation for help.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="228"/>
        <source>(61472 could be used only on mainnet)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="229"/>
        <source>(default: %s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="230"/>
        <source>(default: 1)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="231"/>
        <source>(must be 61472 for mainnet)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="232"/>
        <source>&lt;category&gt; can be:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="233"/>
        <source>Accept command line and JSON-RPC commands</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="234"/>
        <source>Accept connections from outside (default: 1 if no -proxy or -connect)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="235"/>
        <source>Accept public REST requests (default: %u)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="236"/>
        <source>Acceptable ciphers (default: %s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="237"/>
        <source>Add a node to connect to and attempt to keep the connection open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="238"/>
        <source>Allow DNS lookups for -addnode, -seednode and -connect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="239"/>
        <source>Already have that input.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="240"/>
        <source>Always query for peer addresses via DNS lookup (default: %u)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="241"/>
        <source>Attempt to force blockchain corruption recovery</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="242"/>
        <source>Attempt to recover private keys from a corrupt wallet.dat</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="243"/>
        <source>Automatically create Tor hidden service (default: %d)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="244"/>
        <source>Block creation options:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="245"/>
        <source>Calculating missing accumulators...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="246"/>
        <source>Can&apos;t denominate: no compatible inputs left.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="247"/>
        <source>Can&apos;t find random Masternode.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="248"/>
        <source>Can&apos;t mix while sync in progress.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="249"/>
        <source>Cannot downgrade wallet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="250"/>
        <source>Cannot resolve -bind address: &apos;%s&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="251"/>
        <source>Cannot resolve -externalip address: &apos;%s&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="252"/>
        <source>Cannot resolve -whitebind address: &apos;%s&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="253"/>
        <source>Cannot write default address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="254"/>
        <source>Collateral not valid.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="255"/>
        <source>Connect only to the specified node(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="256"/>
        <source>Connect through SOCKS5 proxy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="257"/>
        <source>Connect to a node to retrieve peer addresses, and disconnect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="258"/>
        <source>Connection options:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="259"/>
        <source>Copyright (C) 2009-%i The Bitcoin Core Developers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="260"/>
        <source>Copyright (C) 2014-%i The Dash Core Developers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="261"/>
        <source>Copyright (C) 2015-%i The PIVX Core Developers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="262"/>
        <source>Copyright (C) 2018-%i The NPW Core Developers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="263"/>
        <source>Corrupted block database detected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="264"/>
        <source>Could not parse -rpcbind value %s as network address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="265"/>
        <source>Could not parse masternode.conf</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="266"/>
        <source>Debugging/Testing options:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="267"/>
        <source>Delete blockchain folders and resync from scratch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="268"/>
        <source>Disable OS notifications for incoming transactions (default: %u)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="269"/>
        <source>Disable safemode, override a real safe mode event (default: %u)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="270"/>
        <source>Discover own IP address (default: 1 when listening and no -externalip)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="271"/>
        <source>Display the stake modifier calculations in the debug.log file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="272"/>
        <source>Display verbose coin stake messages in the debug.log file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="273"/>
        <source>Do not load the wallet and disable wallet RPC calls</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="274"/>
        <source>Do you want to rebuild the block database now?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="275"/>
        <source>Done loading</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="276"/>
        <source>Enable automatic Zerocoin minting (0-1, default: %u)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="277"/>
        <source>Enable publish hash block in &lt;address&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="278"/>
        <source>Enable publish hash transaction (locked via SwiftX) in &lt;address&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="279"/>
        <source>Enable publish hash transaction in &lt;address&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="280"/>
        <source>Enable publish raw block in &lt;address&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="281"/>
        <source>Enable publish raw transaction (locked via SwiftX) in &lt;address&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="282"/>
        <source>Enable publish raw transaction in &lt;address&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="283"/>
        <source>Enable staking functionality (0-1, default: %u)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="284"/>
        <source>Enable the client to act as a masternode (0-1, default: %u)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="285"/>
        <source>Entries are full.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="286"/>
        <source>Error connecting to Masternode.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="287"/>
        <source>Error initializing block database</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="288"/>
        <source>Error initializing wallet database environment %s!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="289"/>
        <source>Error loading block database</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="290"/>
        <source>Error loading wallet.dat</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="291"/>
        <source>Error loading wallet.dat: Wallet corrupted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="292"/>
        <source>Error loading wallet.dat: Wallet requires newer version of NPW Core</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="293"/>
        <source>Error opening block database</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="294"/>
        <source>Error reading from database, shutting down.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="295"/>
        <source>Error recovering public key.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="296"/>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="297"/>
        <source>Error: A fatal internal error occured, see debug.log for details</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="298"/>
        <source>Error: Can&apos;t select current denominated inputs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="299"/>
        <source>Error: Disk space is low!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="300"/>
        <source>Error: Unsupported argument -tor found, use -onion.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="301"/>
        <source>Error: Wallet locked, unable to create transaction!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="302"/>
        <source>Error: You already have pending entries in the Obfuscation pool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="303"/>
        <source>Failed to calculate accumulator checkpoint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="304"/>
        <source>Failed to listen on any port. Use -listen=0 if you want this.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="305"/>
        <source>Failed to read block index</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="306"/>
        <source>Failed to read block</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="307"/>
        <source>Failed to write block index</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="308"/>
        <source>Fee (in NPW/kB) to add to transactions you send (default: %s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="309"/>
        <source>Finalizing transaction.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="310"/>
        <source>Force safe mode (default: %u)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="311"/>
        <source>Found enough users, signing ( waiting %s )</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="312"/>
        <source>Found enough users, signing ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="313"/>
        <source>Generate coins (default: %u)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="314"/>
        <source>How many blocks to check at startup (default: %u, 0 = all)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="315"/>
        <source>If &lt;category&gt; is not supplied, output all debugging information.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="316"/>
        <source>Importing...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="317"/>
        <source>Imports blocks from external blk000??.dat file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="318"/>
        <source>Include IP addresses in debug output (default: %u)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="319"/>
        <source>Incompatible mode.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="320"/>
        <source>Incompatible version.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="321"/>
        <source>Incorrect or no genesis block found. Wrong datadir for network?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="322"/>
        <source>Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="323"/>
        <source>Initialization sanity check failed. NPW Core is shutting down.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="324"/>
        <source>Input is not valid.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="325"/>
        <source>Insufficient funds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="326"/>
        <source>Insufficient funds.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="327"/>
        <source>Invalid -onion address or hostname: &apos;%s&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="328"/>
        <source>Invalid -proxy address or hostname: &apos;%s&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="329"/>
        <source>Invalid amount for -maxtxfee=&lt;amount&gt;: &apos;%s&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="330"/>
        <source>Invalid amount for -minrelaytxfee=&lt;amount&gt;: &apos;%s&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="331"/>
        <source>Invalid amount for -mintxfee=&lt;amount&gt;: &apos;%s&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="332"/>
        <source>Invalid amount for -paytxfee=&lt;amount&gt;: &apos;%s&apos; (must be at least %s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="333"/>
        <source>Invalid amount for -paytxfee=&lt;amount&gt;: &apos;%s&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="334"/>
        <source>Invalid amount for -reservebalance=&lt;amount&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="335"/>
        <source>Invalid amount</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="336"/>
        <source>Invalid masternodeprivkey. Please see documenation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="337"/>
        <source>Invalid netmask specified in -whitelist: &apos;%s&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="338"/>
        <source>Invalid port detected in masternode.conf</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="339"/>
        <source>Invalid private key.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="340"/>
        <source>Invalid script detected.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="341"/>
        <source>Keep at most &lt;n&gt; unconnectable transactions in memory (default: %u)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="342"/>
        <source>Last Obfuscation was too recent.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="343"/>
        <source>Last successful Obfuscation action was too recent.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="344"/>
        <source>Limit size of signature cache to &lt;n&gt; entries (default: %u)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="345"/>
        <source>Line: %d</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="346"/>
        <source>Listen for JSON-RPC connections on &lt;port&gt; (default: %u or testnet: %u)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="347"/>
        <source>Listen for connections on &lt;port&gt; (default: %u or testnet: %u)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="348"/>
        <source>Loading addresses...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="349"/>
        <source>Loading block index...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="350"/>
        <source>Loading budget cache...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="351"/>
        <source>Loading masternode cache...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="352"/>
        <source>Loading masternode payment cache...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="353"/>
        <source>Loading sporks...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="354"/>
        <source>Loading wallet... (%3.2f %%)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="355"/>
        <source>Loading wallet...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="356"/>
        <source>Lock is already in place.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="357"/>
        <source>Lock masternodes from masternode configuration file (default: %u)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="358"/>
        <source>Maintain at most &lt;n&gt; connections to peers (default: %u)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="359"/>
        <source>Masternode options:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="360"/>
        <source>Masternode queue is full.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="361"/>
        <source>Masternode:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="362"/>
        <source>Maximum per-connection receive buffer, &lt;n&gt;*1000 bytes (default: %u)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="363"/>
        <source>Maximum per-connection send buffer, &lt;n&gt;*1000 bytes (default: %u)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="364"/>
        <source>Missing input transaction information.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="365"/>
        <source>Mixing in progress...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="366"/>
        <source>Need to specify a port with -whitebind: &apos;%s&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="367"/>
        <source>No Masternodes detected.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="368"/>
        <source>No compatible Masternode found.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="369"/>
        <source>No funds detected in need of denominating.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="370"/>
        <source>No matching denominations found for mixing.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="371"/>
        <source>Node relay options:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="372"/>
        <source>Non-standard public key detected.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="373"/>
        <source>Not compatible with existing transactions.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="374"/>
        <source>Not enough file descriptors available.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="375"/>
        <source>Not in the Masternode list.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="376"/>
        <source>Number of automatic wallet backups (default: 10)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="377"/>
        <source>Obfuscation is idle.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="378"/>
        <source>Obfuscation request complete:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="379"/>
        <source>Obfuscation request incomplete:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="380"/>
        <source>Only accept block chain matching built-in checkpoints (default: %u)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="381"/>
        <source>Only connect to nodes in network &lt;net&gt; (ipv4, ipv6 or onion)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="382"/>
        <source>Options:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="383"/>
        <source>Password for JSON-RPC connections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="384"/>
        <source>Percentage of automatically minted Zerocoin  (10-100, default: %u)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="385"/>
        <source>Preparing for resync...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="386"/>
        <source>Prepend debug output with timestamp (default: %u)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="387"/>
        <source>Print version and exit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="388"/>
        <source>RPC SSL options: (see the Bitcoin Wiki for SSL setup instructions)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="389"/>
        <source>RPC server options:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="390"/>
        <source>RPC support for HTTP persistent connections (default: %d)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="391"/>
        <source>Randomly drop 1 of every &lt;n&gt; network messages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="392"/>
        <source>Randomly fuzz 1 of every &lt;n&gt; network messages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="393"/>
        <source>Rebuild block chain index from current blk000??.dat files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="394"/>
        <source>Recalculating coin supply may take 30-60 minutes...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="395"/>
        <source>Recalculating supply statistics may take 30-60 minutes...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="396"/>
        <source>Receive and display P2P network alerts (default: %u)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="397"/>
        <source>Reindex the accumulator database</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="398"/>
        <source>Relay and mine data carrier transactions (default: %u)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="399"/>
        <source>Relay non-P2SH multisig (default: %u)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="400"/>
        <source>Rescan the block chain for missing wallet transactions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="401"/>
        <source>Rescanning...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="402"/>
        <source>ResetMintZerocoin finished: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="403"/>
        <source>ResetSpentZerocoin finished: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="404"/>
        <source>Run a thread to flush wallet periodically (default: %u)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="405"/>
        <source>Run in the background as a daemon and accept commands</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="406"/>
        <source>Send transactions as zero-fee transactions if possible (default: %u)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="407"/>
        <source>Server certificate file (default: %s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="408"/>
        <source>Server private key (default: %s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="409"/>
        <source>Session not complete!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="410"/>
        <source>Session timed out.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="411"/>
        <source>Set database cache size in megabytes (%d to %d, default: %d)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="412"/>
        <source>Set external address:port to get to this masternode (example: %s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="413"/>
        <source>Set key pool size to &lt;n&gt; (default: %u)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="414"/>
        <source>Set maximum block size in bytes (default: %d)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="415"/>
        <source>Set minimum block size in bytes (default: %u)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="416"/>
        <source>Set the Maximum reorg depth (default: %u)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="417"/>
        <source>Set the masternode private key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="418"/>
        <source>Set the number of threads to service RPC calls (default: %d)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="419"/>
        <source>Sets the DB_PRIVATE flag in the wallet db environment (default: %u)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="420"/>
        <source>Show all debugging options (usage: --help -help-debug)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="421"/>
        <source>Shrink debug.log file on client startup (default: 1 when no -debug)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="422"/>
        <source>Signing failed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="423"/>
        <source>Signing timed out.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="424"/>
        <source>Signing transaction failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="425"/>
        <source>Specify configuration file (default: %s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="426"/>
        <source>Specify connection timeout in milliseconds (minimum: 1, default: %d)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="427"/>
        <source>Specify data directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="428"/>
        <source>Specify masternode configuration file (default: %s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="429"/>
        <source>Specify pid file (default: %s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="430"/>
        <source>Specify wallet file (within data directory)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="431"/>
        <source>Specify your own public address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="432"/>
        <source>Spend unconfirmed change when sending transactions (default: %u)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="433"/>
        <source>Staking options:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="434"/>
        <source>Stop running after importing blocks from disk (default: %u)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="435"/>
        <source>Submitted following entries to masternode: %u / %d</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="436"/>
        <source>Submitted to masternode, waiting for more entries ( %u / %d ) %s</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="437"/>
        <source>Submitted to masternode, waiting in queue %s</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="438"/>
        <source>SwiftX options:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="439"/>
        <source>Synchronization failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="440"/>
        <source>Synchronization finished</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="441"/>
        <source>Synchronization pending...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="442"/>
        <source>Synchronizing budgets...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="443"/>
        <source>Synchronizing masternode winners...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="444"/>
        <source>Synchronizing masternodes...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="445"/>
        <source>Synchronizing sporks...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="446"/>
        <source>This help message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="447"/>
        <source>This is experimental software.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="448"/>
        <source>This is intended for regression testing tools and app development.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="449"/>
        <source>This is not a Masternode.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="450"/>
        <source>Threshold for disconnecting misbehaving peers (default: %u)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="451"/>
        <source>Tor control port password (default: empty)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="452"/>
        <source>Tor control port to use if onion listening enabled (default: %s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="453"/>
        <source>Transaction amount too small</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="454"/>
        <source>Transaction amounts must be positive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="455"/>
        <source>Transaction created successfully.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="456"/>
        <source>Transaction fees are too high.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="457"/>
        <source>Transaction not valid.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="458"/>
        <source>Transaction too large for fee policy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="459"/>
        <source>Transaction too large</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="460"/>
        <source>Transmitting final transaction.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="461"/>
        <source>Unable to bind to %s on this computer (bind returned error %s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="462"/>
        <source>Unable to sign spork message, wrong key?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="463"/>
        <source>Unknown network specified in -onlynet: &apos;%s&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="464"/>
        <source>Unknown state: id = %u</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="465"/>
        <source>Upgrade wallet to latest format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="466"/>
        <source>Use OpenSSL (https) for JSON-RPC connections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="467"/>
        <source>Use UPnP to map the listening port (default: %u)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="468"/>
        <source>Use UPnP to map the listening port (default: 1 when listening)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="469"/>
        <source>Use a custom max chain reorganization depth (default: %u)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="470"/>
        <source>Use the test network</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="471"/>
        <source>Username for JSON-RPC connections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="472"/>
        <source>Value more than Obfuscation pool maximum allows.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="473"/>
        <source>Verifying blocks...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="474"/>
        <source>Verifying wallet...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="475"/>
        <source>Wallet %s resides outside data directory %s</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="476"/>
        <source>Wallet is locked.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="477"/>
        <source>Wallet needed to be rewritten: restart NPW Core to complete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="478"/>
        <source>Wallet options:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="479"/>
        <source>Wallet window title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="480"/>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="481"/>
        <source>Warning: This version is obsolete, upgrade required!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="482"/>
        <source>Warning: Unsupported argument -benchmark ignored, use -debug=bench.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="483"/>
        <source>Warning: Unsupported argument -debugnet ignored, use -debug=net.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="484"/>
        <source>Will retry...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="485"/>
        <source>You need to rebuild the database using -reindex to change -txindex</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="486"/>
        <source>Your entries added successfully.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="487"/>
        <source>Your transaction was accepted into the pool!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="488"/>
        <source>Zapping all transactions from wallet...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="489"/>
        <source>ZeroMQ notification options:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="490"/>
        <source>Zerocoin options:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="491"/>
        <source>failed to validate zerocoin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="492"/>
        <source>on startup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../npwstrings.cpp" line="493"/>
        <source>wallet.dat corrupt, salvage failed</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
