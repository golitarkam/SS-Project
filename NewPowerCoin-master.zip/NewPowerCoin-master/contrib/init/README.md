Sample configuration files for:

SystemD: npwd.service
Upstart: npwd.conf
OpenRC:  npwd.openrc
         npwd.openrcconf
CentOS:  npwd.init

have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
